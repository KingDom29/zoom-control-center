/**
 * Maklerplan Meeting Scheduler
 * Verteilt Meetings automatisch auf Mo-Fr, 9-17 Uhr
 */

class MeetingScheduler {
  constructor(config) {
    this.config = {
      startDate: new Date(config.startDate || process.env.CAMPAIGN_START_DATE),
      endDate: config.endDate ? new Date(config.endDate) : null,
      startHour: parseInt(config.startHour || process.env.MEETING_START_HOUR || 9),
      endHour: parseInt(config.endHour || process.env.MEETING_END_HOUR || 17),
      durationMinutes: parseInt(config.durationMinutes || process.env.MEETING_DURATION_MINUTES || 30),
      bufferMinutes: parseInt(config.bufferMinutes || process.env.MEETING_BUFFER_MINUTES || 15),
      // 1=Mo, 2=Di, 3=Mi, 4=Do, 5=Fr
      allowedDays: (config.allowedDays || process.env.MEETING_DAYS || '1,2,3,4,5')
        .split(',').map(d => parseInt(d.trim())),
      timezone: config.timezone || 'Europe/Berlin'
    };
    
    this.scheduledSlots = new Map(); // date-time -> contact
    this.slotDuration = this.config.durationMinutes + this.config.bufferMinutes;
  }

  /**
   * Generiert alle verfügbaren Slots ab Startdatum
   */
  generateAvailableSlots(numberOfSlots = 100) {
    const slots = [];
    let currentDate = new Date(this.config.startDate);
    
    while (slots.length < numberOfSlots) {
      // Prüfen ob Wochentag erlaubt ist (getDay(): 0=So, 1=Mo, ...)
      const dayOfWeek = currentDate.getDay();
      
      if (this.config.allowedDays.includes(dayOfWeek)) {
        // Slots für diesen Tag generieren
        const daySlots = this.generateDaySlots(currentDate);
        slots.push(...daySlots);
      }
      
      // Nächster Tag
      currentDate.setDate(currentDate.getDate() + 1);
      
      // Sicherheits-Limit: max 1 Jahr in die Zukunft
      if (currentDate > new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)) {
        break;
      }
    }
    
    return slots.slice(0, numberOfSlots);
  }

  /**
   * Generiert alle Slots für einen Tag
   */
  generateDaySlots(date) {
    const slots = [];
    const year = date.getFullYear();
    const month = date.getMonth();
    const day = date.getDate();
    
    let currentHour = this.config.startHour;
    let currentMinute = 0;
    
    while (currentHour < this.config.endHour || 
           (currentHour === this.config.endHour && currentMinute === 0)) {
      
      // Letzter Slot muss noch vor endHour enden
      const slotEnd = currentHour * 60 + currentMinute + this.config.durationMinutes;
      if (slotEnd > this.config.endHour * 60) break;
      
      const slotDate = new Date(year, month, day, currentHour, currentMinute, 0);
      const slotKey = this.getSlotKey(slotDate);
      
      // Nur wenn Slot noch nicht vergeben ist
      if (!this.scheduledSlots.has(slotKey)) {
        slots.push({
          date: slotDate,
          dateISO: slotDate.toISOString(),
          dateFormatted: this.formatDate(slotDate),
          timeFormatted: this.formatTime(slotDate),
          dayOfWeek: this.getDayName(slotDate.getDay()),
          slotKey
        });
      }
      
      // Nächster Slot (Meeting + Buffer)
      currentMinute += this.slotDuration;
      if (currentMinute >= 60) {
        currentHour += Math.floor(currentMinute / 60);
        currentMinute = currentMinute % 60;
      }
    }
    
    return slots;
  }

  /**
   * Plant Meetings für eine Liste von Kontakten
   */
  scheduleForContacts(contacts) {
    const slots = this.generateAvailableSlots(contacts.length + 20); // Etwas Puffer
    const scheduled = [];
    const failed = [];
    
    contacts.forEach((contact, index) => {
      if (index < slots.length) {
        const slot = slots[index];
        
        // Slot reservieren
        this.scheduledSlots.set(slot.slotKey, contact);
        
        scheduled.push({
          contact,
          slot,
          meetingTopic: this.generateMeetingTopic(contact),
          meetingAgenda: this.generateMeetingAgenda(contact)
        });
      } else {
        failed.push({
          contact,
          reason: 'Keine verfügbaren Slots mehr'
        });
      }
    });
    
    return { scheduled, failed };
  }

  /**
   * Meeting-Thema generieren
   */
  generateMeetingTopic(contact) {
    const companyName = contact.company || contact.name;
    return `Neujahres-Update 2026 | Maklerplan × ${companyName}`;
  }

  /**
   * Meeting-Agenda generieren
   */
  generateMeetingAgenda(contact) {
    return `
Neujahres-Update 2026 – Maklerplan GmbH

Teilnehmer:
• Herbert Nicklaus (Maklerplan)
• Dominik Eisenhardt (Maklerplan)
• ${contact.name} (${contact.company || 'Gast'})

Agenda:
1. Begrüßung & Rückblick 2025 (5 Min)
2. Neue Features & Updates für 2026 (10 Min)
3. Ihre Erfahrungen & Feedback (10 Min)
4. Ausblick & nächste Schritte (5 Min)

Bei Fragen vorab: info@maklerplan.de
    `.trim();
  }

  /**
   * Hilfsfunktionen
   */
  getSlotKey(date) {
    return date.toISOString().slice(0, 16); // YYYY-MM-DDTHH:MM
  }

  formatDate(date) {
    return date.toLocaleDateString('de-DE', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }

  formatTime(date) {
    return date.toLocaleTimeString('de-DE', {
      hour: '2-digit',
      minute: '2-digit'
    });
  }

  getDayName(dayIndex) {
    const days = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];
    return days[dayIndex];
  }

  /**
   * Statistiken
   */
  getStats() {
    const slots = this.generateAvailableSlots(200);
    const slotsPerDay = {};
    
    slots.forEach(slot => {
      const dateKey = slot.date.toISOString().slice(0, 10);
      slotsPerDay[dateKey] = (slotsPerDay[dateKey] || 0) + 1;
    });
    
    return {
      totalAvailableSlots: slots.length,
      scheduledSlots: this.scheduledSlots.size,
      remainingSlots: slots.length - this.scheduledSlots.size,
      slotsPerDay,
      config: this.config
    };
  }
}

module.exports = { MeetingScheduler };
