/**
 * Maklerplan Campaign Manager
 * Orchestriert die gesamte Neujahres-Kampagne
 */

const { MeetingScheduler } = require('./meetingScheduler');
const { emailService } = require('./emailService');

class CampaignManager {
  constructor(zoomService) {
    this.zoomService = zoomService;
    this.scheduler = null;
    this.contacts = [];
    this.scheduledMeetings = [];
    this.emailQueue = [];
    this.status = 'idle'; // idle, running, paused, completed
    this.stats = {
      totalContacts: 0,
      meetingsCreated: 0,
      invitationsSent: 0,
      remindersSent: 0,
      followUpsSent: 0,
      errors: []
    };
  }

  /**
   * Initialisiert die Kampagne
   */
  async initialize(config = {}) {
    console.log('🚀 Initialisiere Neujahres-Kampagne 2026...');

    // Scheduler mit Konfiguration erstellen
    this.scheduler = new MeetingScheduler({
      startDate: config.startDate || process.env.CAMPAIGN_START_DATE || '2026-01-19',
      startHour: config.startHour || process.env.MEETING_START_HOUR || 9,
      endHour: config.endHour || process.env.MEETING_END_HOUR || 17,
      durationMinutes: config.durationMinutes || process.env.MEETING_DURATION_MINUTES || 30,
      bufferMinutes: config.bufferMinutes || process.env.MEETING_BUFFER_MINUTES || 15,
      allowedDays: config.allowedDays || process.env.MEETING_DAYS || '1,2,3,4,5'
    });

    // E-Mail Service initialisieren
    await emailService.initialize();

    console.log('✅ Kampagne initialisiert');
    return this.getConfig();
  }

  /**
   * Lädt und verarbeitet die Kontaktliste
   */
  loadContacts(contactList) {
    this.contacts = contactList.map((contact, index) => ({
      id: contact.id || `contact-${index + 1}`,
      salutation: contact.salutation || contact.anrede || 'Herr/Frau',
      firstName: contact.firstName || contact.vorname || contact.name?.split(' ')[0] || '',
      lastName: contact.lastName || contact.nachname || contact.name?.split(' ').slice(1).join(' ') || contact.name || '',
      email: contact.email || contact.mail || contact.Email,
      company: contact.company || contact.firma || contact.unternehmen || '',
      phone: contact.phone || contact.telefon || '',
      notes: contact.notes || contact.notizen || '',
      status: 'pending', // pending, scheduled, invited, reminded, completed, cancelled
      meetingId: null,
      ...contact
    }));

    this.stats.totalContacts = this.contacts.length;
    console.log(`📋 ${this.contacts.length} Kontakte geladen`);
    
    return {
      loaded: this.contacts.length,
      contacts: this.contacts
    };
  }

  /**
   * Plant alle Meetings
   */
  async scheduleAllMeetings() {
    if (!this.scheduler) {
      throw new Error('Kampagne nicht initialisiert');
    }

    if (this.contacts.length === 0) {
      throw new Error('Keine Kontakte geladen');
    }

    console.log(`📅 Plane ${this.contacts.length} Meetings...`);
    this.status = 'running';

    const { scheduled, failed } = this.scheduler.scheduleForContacts(this.contacts);

    // Zoom-Meetings erstellen
    for (const item of scheduled) {
      try {
        const zoomMeeting = await this.createZoomMeeting(item);
        
        this.scheduledMeetings.push({
          ...item,
          zoomMeeting,
          zoomJoinUrl: zoomMeeting.join_url,
          zoomMeetingId: zoomMeeting.id,
          zoomPassword: zoomMeeting.password
        });

        // Kontakt-Status aktualisieren
        const contact = this.contacts.find(c => c.id === item.contact.id);
        if (contact) {
          contact.status = 'scheduled';
          contact.meetingId = zoomMeeting.id;
          contact.meetingDate = item.slot.dateISO;
        }

        this.stats.meetingsCreated++;
        console.log(`✅ Meeting erstellt: ${item.contact.lastName} - ${item.slot.dateFormatted} ${item.slot.timeFormatted}`);

      } catch (error) {
        console.error(`❌ Meeting-Erstellung fehlgeschlagen für ${item.contact.email}:`, error.message);
        this.stats.errors.push({
          type: 'meeting_creation',
          contact: item.contact.email,
          error: error.message
        });
      }
    }

    return {
      scheduled: this.scheduledMeetings.length,
      failed: failed.length + this.stats.errors.length,
      meetings: this.scheduledMeetings
    };
  }

  /**
   * Erstellt ein Zoom-Meeting
   */
  async createZoomMeeting(item) {
    // Falls Zoom Service nicht verfügbar, Mock-Daten zurückgeben
    if (!this.zoomService) {
      return this.createMockMeeting(item);
    }

    const meetingData = {
      topic: item.meetingTopic,
      type: 2, // Scheduled Meeting
      start_time: item.slot.dateISO,
      duration: parseInt(process.env.MEETING_DURATION_MINUTES || 30),
      timezone: 'Europe/Berlin',
      agenda: item.meetingAgenda,
      settings: {
        host_video: true,
        participant_video: true,
        join_before_host: false,
        mute_upon_entry: true,
        waiting_room: true,
        auto_recording: 'cloud',
        meeting_authentication: false,
        alternative_hosts: process.env.HOST_2_EMAIL || ''
      }
    };

    return await this.zoomService.createMeeting(meetingData);
  }

  /**
   * Mock-Meeting für Tests ohne Zoom API
   */
  createMockMeeting(item) {
    const mockId = Math.floor(Math.random() * 9000000000) + 1000000000;
    return {
      id: mockId,
      join_url: `https://zoom.us/j/${mockId}`,
      password: Math.random().toString(36).substring(2, 8),
      topic: item.meetingTopic,
      start_time: item.slot.dateISO,
      duration: 30
    };
  }

  /**
   * Sendet alle Einladungs-E-Mails
   */
  async sendAllInvitations() {
    console.log(`📧 Sende ${this.scheduledMeetings.length} Einladungen...`);
    
    const results = [];
    
    for (const meeting of this.scheduledMeetings) {
      if (meeting.contact.status === 'scheduled') {
        try {
          const result = await emailService.sendInvitation(meeting.contact, meeting);
          
          if (result.success) {
            meeting.contact.status = 'invited';
            meeting.invitationSent = new Date().toISOString();
            this.stats.invitationsSent++;
          }
          
          results.push({ contact: meeting.contact.email, ...result });
          
          // 2 Sekunden Pause zwischen E-Mails
          await new Promise(resolve => setTimeout(resolve, 2000));
          
        } catch (error) {
          results.push({ contact: meeting.contact.email, success: false, error: error.message });
          this.stats.errors.push({
            type: 'invitation_email',
            contact: meeting.contact.email,
            error: error.message
          });
        }
      }
    }

    return {
      sent: this.stats.invitationsSent,
      results
    };
  }

  /**
   * Sendet Reminder für Meetings am nächsten Tag
   */
  async sendDueReminders() {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().slice(0, 10);

    const dueReminders = this.scheduledMeetings.filter(m => {
      const meetingDate = new Date(m.slot.dateISO).toISOString().slice(0, 10);
      return meetingDate === tomorrowStr && m.contact.status === 'invited';
    });

    console.log(`⏰ Sende ${dueReminders.length} Reminder für morgen...`);

    for (const meeting of dueReminders) {
      try {
        const result = await emailService.sendReminder(meeting.contact, meeting);
        
        if (result.success) {
          meeting.contact.status = 'reminded';
          meeting.reminderSent = new Date().toISOString();
          this.stats.remindersSent++;
        }
        
        await new Promise(resolve => setTimeout(resolve, 2000));
        
      } catch (error) {
        this.stats.errors.push({
          type: 'reminder_email',
          contact: meeting.contact.email,
          error: error.message
        });
      }
    }

    return { sent: dueReminders.length };
  }

  /**
   * Sendet Follow-Ups für gestrige Meetings
   */
  async sendDueFollowUps() {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().slice(0, 10);

    const dueFollowUps = this.scheduledMeetings.filter(m => {
      const meetingDate = new Date(m.slot.dateISO).toISOString().slice(0, 10);
      return meetingDate === yesterdayStr && 
             (m.contact.status === 'reminded' || m.contact.status === 'invited');
    });

    console.log(`✅ Sende ${dueFollowUps.length} Follow-Ups...`);

    for (const meeting of dueFollowUps) {
      try {
        const result = await emailService.sendFollowUp(meeting.contact, meeting);
        
        if (result.success) {
          meeting.contact.status = 'completed';
          meeting.followUpSent = new Date().toISOString();
          this.stats.followUpsSent++;
        }
        
        await new Promise(resolve => setTimeout(resolve, 2000));
        
      } catch (error) {
        this.stats.errors.push({
          type: 'followup_email',
          contact: meeting.contact.email,
          error: error.message
        });
      }
    }

    return { sent: dueFollowUps.length };
  }

  /**
   * Führt die komplette Kampagne aus
   */
  async runFullCampaign() {
    console.log('\n════════════════════════════════════════');
    console.log('   MAKLERPLAN NEUJAHRES-UPDATE 2026');
    console.log('════════════════════════════════════════\n');

    // 1. Meetings planen
    const meetingResult = await this.scheduleAllMeetings();
    console.log(`\n📅 ${meetingResult.scheduled} Meetings geplant`);

    // 2. Einladungen senden
    const inviteResult = await this.sendAllInvitations();
    console.log(`📧 ${inviteResult.sent} Einladungen gesendet`);

    this.status = 'completed';

    return {
      meetings: meetingResult,
      invitations: inviteResult,
      stats: this.getStats()
    };
  }

  /**
   * Konfiguration abrufen
   */
  getConfig() {
    return {
      campaign: {
        name: process.env.CAMPAIGN_NAME || 'Neujahres-Update 2026',
        startDate: process.env.CAMPAIGN_START_DATE,
        endDate: process.env.CAMPAIGN_END_DATE
      },
      meetings: {
        startHour: process.env.MEETING_START_HOUR,
        endHour: process.env.MEETING_END_HOUR,
        duration: process.env.MEETING_DURATION_MINUTES,
        buffer: process.env.MEETING_BUFFER_MINUTES,
        days: process.env.MEETING_DAYS
      },
      hosts: [
        { name: process.env.HOST_1_NAME, email: process.env.HOST_1_EMAIL },
        { name: process.env.HOST_2_NAME, email: process.env.HOST_2_EMAIL }
      ],
      email: {
        from: process.env.EMAIL_FROM_ADDRESS,
        inviteDaysBefore: process.env.EMAIL_INVITE_DAYS_BEFORE,
        reminderDaysBefore: process.env.EMAIL_REMINDER_DAYS_BEFORE,
        followUpDaysAfter: process.env.EMAIL_FOLLOWUP_DAYS_AFTER
      }
    };
  }

  /**
   * Statistiken abrufen
   */
  getStats() {
    return {
      ...this.stats,
      status: this.status,
      contacts: {
        total: this.contacts.length,
        pending: this.contacts.filter(c => c.status === 'pending').length,
        scheduled: this.contacts.filter(c => c.status === 'scheduled').length,
        invited: this.contacts.filter(c => c.status === 'invited').length,
        reminded: this.contacts.filter(c => c.status === 'reminded').length,
        completed: this.contacts.filter(c => c.status === 'completed').length
      },
      schedulerStats: this.scheduler?.getStats() || null
    };
  }

  /**
   * Export der Meetings als CSV
   */
  exportMeetingsCSV() {
    const headers = ['Datum', 'Uhrzeit', 'Firma', 'Name', 'E-Mail', 'Meeting-ID', 'Join-URL', 'Status'];
    const rows = this.scheduledMeetings.map(m => [
      m.slot.dateFormatted,
      m.slot.timeFormatted,
      m.contact.company,
      `${m.contact.firstName} ${m.contact.lastName}`,
      m.contact.email,
      m.zoomMeetingId,
      m.zoomJoinUrl,
      m.contact.status
    ]);

    return [headers, ...rows].map(row => row.join(';')).join('\n');
  }

  /**
   * Kalender-Export als ICS
   */
  exportCalendarICS() {
    const events = this.scheduledMeetings.map(m => {
      const start = new Date(m.slot.dateISO);
      const end = new Date(start.getTime() + 30 * 60000);
      
      return `BEGIN:VEVENT
DTSTART:${start.toISOString().replace(/[-:]/g, '').split('.')[0]}Z
DTEND:${end.toISOString().replace(/[-:]/g, '').split('.')[0]}Z
SUMMARY:${m.meetingTopic}
DESCRIPTION:${m.zoomJoinUrl}
LOCATION:Zoom
UID:${m.zoomMeetingId}@maklerplan.de
END:VEVENT`;
    });

    return `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Maklerplan GmbH//Campaign Manager//DE
${events.join('\n')}
END:VCALENDAR`;
  }
}

module.exports = { CampaignManager };
