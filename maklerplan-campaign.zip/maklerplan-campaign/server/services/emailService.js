/**
 * Maklerplan E-Mail Service
 * Versendet E-Mails über SMTP (Office 365, Gmail, etc.)
 */

const nodemailer = require('nodemailer');
const { emailTemplates } = require('../templates/emailTemplates');

class EmailService {
  constructor() {
    this.transporter = null;
    this.isConfigured = false;
    this.sentEmails = [];
    this.failedEmails = [];
  }

  /**
   * Initialisiert den SMTP-Transporter
   */
  async initialize() {
    try {
      this.transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT || 587),
        secure: process.env.SMTP_SECURE === 'true',
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASSWORD
        },
        tls: {
          rejectUnauthorized: false
        }
      });

      // Verbindung testen
      await this.transporter.verify();
      this.isConfigured = true;
      console.log('✅ E-Mail Service initialisiert');
      return true;
    } catch (error) {
      console.error('❌ E-Mail Service Fehler:', error.message);
      this.isConfigured = false;
      return false;
    }
  }

  /**
   * Sendet eine E-Mail
   */
  async sendEmail(to, subject, html, text, options = {}) {
    if (!this.isConfigured) {
      throw new Error('E-Mail Service nicht initialisiert');
    }

    const mailOptions = {
      from: `"${process.env.EMAIL_FROM_NAME || 'Maklerplan GmbH'}" <${process.env.EMAIL_FROM_ADDRESS || process.env.SMTP_USER}>`,
      replyTo: process.env.EMAIL_REPLY_TO || process.env.SMTP_USER,
      to,
      subject,
      html,
      text,
      ...options
    };

    try {
      const result = await this.transporter.sendMail(mailOptions);
      
      this.sentEmails.push({
        to,
        subject,
        messageId: result.messageId,
        sentAt: new Date().toISOString()
      });

      console.log(`📧 E-Mail gesendet an ${to}: ${subject}`);
      return { success: true, messageId: result.messageId };
    } catch (error) {
      this.failedEmails.push({
        to,
        subject,
        error: error.message,
        attemptedAt: new Date().toISOString()
      });

      console.error(`❌ E-Mail fehlgeschlagen an ${to}:`, error.message);
      return { success: false, error: error.message };
    }
  }

  /**
   * Sendet eine Einladungs-E-Mail
   */
  async sendInvitation(contact, meetingData) {
    const templateData = {
      salutation: contact.salutation || 'Herr/Frau',
      firstName: contact.firstName,
      lastName: contact.lastName,
      meetingDate: meetingData.slot.dateFormatted,
      meetingDateFormatted: meetingData.slot.dateFormatted,
      meetingTime: meetingData.slot.timeFormatted,
      zoomJoinUrl: meetingData.zoomJoinUrl,
      zoomMeetingId: meetingData.zoomMeetingId,
      zoomPassword: meetingData.zoomPassword,
      unsubscribeUrl: `${process.env.COMPANY_WEBSITE}/unsubscribe?email=${contact.email}`
    };

    const template = emailTemplates.invitation(templateData);
    return this.sendEmail(contact.email, template.subject, template.html, template.text);
  }

  /**
   * Sendet eine Erinnerungs-E-Mail
   */
  async sendReminder(contact, meetingData) {
    const templateData = {
      salutation: contact.salutation || 'Herr/Frau',
      firstName: contact.firstName,
      lastName: contact.lastName,
      meetingDateFormatted: meetingData.slot.dateFormatted,
      meetingTime: meetingData.slot.timeFormatted,
      zoomJoinUrl: meetingData.zoomJoinUrl,
      zoomMeetingId: meetingData.zoomMeetingId
    };

    const template = emailTemplates.reminder(templateData);
    return this.sendEmail(contact.email, template.subject, template.html, template.text);
  }

  /**
   * Sendet eine Follow-Up E-Mail
   */
  async sendFollowUp(contact, meetingData, extras = {}) {
    const templateData = {
      salutation: contact.salutation || 'Herr/Frau',
      firstName: contact.firstName,
      lastName: contact.lastName,
      meetingSummary: extras.summary || null,
      actionItems: extras.actionItems || null,
      recordingUrl: extras.recordingUrl || null
    };

    const template = emailTemplates.followUp(templateData);
    return this.sendEmail(contact.email, template.subject, template.html, template.text);
  }

  /**
   * Batch-Versand mit Verzögerung
   */
  async sendBatch(emails, delayMs = 2000) {
    const results = [];
    
    for (const email of emails) {
      const result = await this.sendEmail(
        email.to,
        email.subject,
        email.html,
        email.text
      );
      results.push({ ...email, result });
      
      // Verzögerung zwischen E-Mails (Rate Limiting)
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }

    return results;
  }

  /**
   * Statistiken
   */
  getStats() {
    return {
      sent: this.sentEmails.length,
      failed: this.failedEmails.length,
      isConfigured: this.isConfigured,
      recentSent: this.sentEmails.slice(-10),
      recentFailed: this.failedEmails.slice(-10)
    };
  }

  /**
   * Test-E-Mail senden
   */
  async sendTestEmail(to) {
    const testHtml = `
      <div style="font-family: Arial, sans-serif; padding: 20px;">
        <h1 style="color: #1e40af;">🧪 Test E-Mail</h1>
        <p>Dies ist eine Test-E-Mail vom Maklerplan Control Center.</p>
        <p><strong>Zeitstempel:</strong> ${new Date().toLocaleString('de-DE')}</p>
        <p><strong>Konfiguration:</strong></p>
        <ul>
          <li>SMTP Host: ${process.env.SMTP_HOST}</li>
          <li>Absender: ${process.env.EMAIL_FROM_ADDRESS}</li>
        </ul>
        <p>Wenn Sie diese E-Mail sehen, funktioniert der E-Mail-Versand! ✅</p>
      </div>
    `;

    return this.sendEmail(
      to,
      '🧪 Test E-Mail | Maklerplan Control Center',
      testHtml,
      'Dies ist eine Test-E-Mail vom Maklerplan Control Center.'
    );
  }
}

// Singleton Export
const emailService = new EmailService();
module.exports = { EmailService, emailService };
