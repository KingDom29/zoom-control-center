/**
 * Maklerplan Control Center - Main Server
 * Kombiniert Zoom API, Kampagnen-Management und Echtzeit-Features
 */

require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const path = require('path');

// Services
const { CampaignManager } = require('./services/campaignManager');
const { emailService } = require('./services/emailService');

// Routes
const { createCampaignRoutes } = require('./routes/campaignRoutes');

// App Setup
const app = express();
const server = http.createServer(app);

// Middleware
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));

// Request Logging
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`${timestamp} | ${req.method} ${req.path}`);
  next();
});

// ═══════════════════════════════════════════════════════════════════════════════
// ZOOM SERVICE (Optional - falls API Credentials vorhanden)
// ═══════════════════════════════════════════════════════════════════════════════
let zoomService = null;

async function initZoomService() {
  if (process.env.ZOOM_CLIENT_ID && process.env.ZOOM_CLIENT_SECRET) {
    try {
      // Hier könnte dein bestehender ZoomAuthService importiert werden
      // const { ZoomAuthService } = require('./services/zoomAuth');
      // zoomService = new ZoomAuthService();
      // await zoomService.initialize();
      console.log('✅ Zoom API Service initialisiert');
    } catch (error) {
      console.warn('⚠️ Zoom API nicht verfügbar:', error.message);
    }
  } else {
    console.log('ℹ️ Zoom API Credentials nicht konfiguriert - Mock-Modus aktiv');
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// CAMPAIGN MANAGER
// ═══════════════════════════════════════════════════════════════════════════════
const campaignManager = new CampaignManager(zoomService);

// ═══════════════════════════════════════════════════════════════════════════════
// ROUTES
// ═══════════════════════════════════════════════════════════════════════════════

// Health Check
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    services: {
      zoom: zoomService ? 'connected' : 'mock-mode',
      email: emailService.isConfigured ? 'configured' : 'not-configured',
      campaign: campaignManager.status
    }
  });
});

// API Info
app.get('/api', (req, res) => {
  res.json({
    name: 'Maklerplan Control Center',
    version: '2.0.0',
    campaign: process.env.CAMPAIGN_NAME || 'Neujahres-Update 2026',
    endpoints: {
      campaign: {
        'GET /api/campaign/config': 'Kampagnen-Konfiguration',
        'GET /api/campaign/stats': 'Statistiken',
        'GET /api/campaign/contacts': 'Kontaktliste',
        'POST /api/campaign/contacts': 'Kontakte laden (JSON)',
        'POST /api/campaign/contacts/upload': 'Kontakte hochladen (CSV)',
        'GET /api/campaign/meetings': 'Geplante Meetings',
        'POST /api/campaign/schedule': 'Meetings planen',
        'POST /api/campaign/send-invitations': 'Einladungen senden',
        'POST /api/campaign/send-reminders': 'Reminder senden',
        'POST /api/campaign/send-followups': 'Follow-Ups senden',
        'POST /api/campaign/run': 'Komplette Kampagne starten',
        'GET /api/campaign/export/csv': 'CSV Export',
        'GET /api/campaign/export/ics': 'Kalender Export',
        'POST /api/campaign/email/test': 'Test-E-Mail senden',
        'GET /api/campaign/preview/slots': 'Verfügbare Slots'
      }
    }
  });
});

// Campaign Routes
const campaignRoutes = createCampaignRoutes(campaignManager);
app.use('/api/campaign', campaignRoutes);

// Env Check Route (nur für Entwicklung)
app.get('/api/env-check', (req, res) => {
  res.json({
    zoom: {
      accountId: process.env.ZOOM_ACCOUNT_ID ? '✅ Set' : '❌ Missing',
      clientId: process.env.ZOOM_CLIENT_ID ? '✅ Set' : '❌ Missing',
      clientSecret: process.env.ZOOM_CLIENT_SECRET ? '✅ Set' : '❌ Missing'
    },
    email: {
      smtpHost: process.env.SMTP_HOST ? '✅ Set' : '❌ Missing',
      smtpUser: process.env.SMTP_USER ? '✅ Set' : '❌ Missing',
      smtpPassword: process.env.SMTP_PASSWORD ? '✅ Set' : '❌ Missing'
    },
    campaign: {
      name: process.env.CAMPAIGN_NAME || '❌ Missing',
      startDate: process.env.CAMPAIGN_START_DATE || '❌ Missing',
      host1: process.env.HOST_1_NAME || '❌ Missing',
      host2: process.env.HOST_2_NAME || '❌ Missing'
    }
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
// STARTUP
// ═══════════════════════════════════════════════════════════════════════════════

async function startServer() {
  const PORT = process.env.PORT || 3001;

  // Services initialisieren
  await initZoomService();
  await campaignManager.initialize();
  
  // E-Mail Service initialisieren (optional)
  if (process.env.SMTP_HOST) {
    await emailService.initialize();
  }

  server.listen(PORT, () => {
    console.log(`
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║   🚀 MAKLERPLAN CONTROL CENTER                                 ║
║                                                                ║
║   Kampagne: ${(process.env.CAMPAIGN_NAME || 'Neujahres-Update 2026').padEnd(42)}║
║   Start:    ${(process.env.CAMPAIGN_START_DATE || '2026-01-19').padEnd(42)}║
║   Hosts:    Herbert Nicklaus, Dominik Eisenhardt               ║
║                                                                ║
║   Server:   http://localhost:${PORT}                             ║
║   API:      http://localhost:${PORT}/api                         ║
║                                                                ║
║   Quick Start:                                                 ║
║   1. POST /api/campaign/contacts     → Kontakte laden          ║
║   2. POST /api/campaign/schedule     → Meetings planen         ║
║   3. POST /api/campaign/send-invitations → E-Mails senden      ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
    `);
  });
}

startServer().catch(console.error);

// Graceful Shutdown
process.on('SIGTERM', () => {
  console.log('Shutting down...');
  server.close(() => process.exit(0));
});

module.exports = { app, server, campaignManager };
