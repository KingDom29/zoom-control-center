/**
 * Maklerplan E-Mail Templates
 * Professionelle HTML E-Mails für die Neujahrs-Kampagne
 */

const emailTemplates = {
  
  /**
   * EINLADUNGS-EMAIL
   * Wird X Tage vor dem Meeting gesendet
   */
  invitation: (data) => ({
    subject: `Einladung: Neujahres-Update 2026 | ${data.meetingDate}`,
    html: `
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Neujahres-Update 2026</title>
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); padding: 40px 40px 30px;">
              <table width="100%">
                <tr>
                  <td>
                    <h1 style="color: #ffffff; margin: 0; font-size: 28px; font-weight: 600;">
                      🎉 Neujahres-Update 2026
                    </h1>
                    <p style="color: rgba(255,255,255,0.9); margin: 10px 0 0; font-size: 16px;">
                      Ihr persönlicher Termin mit dem Maklerplan-Team
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
          <!-- Body -->
          <tr>
            <td style="padding: 40px;">
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 20px;">
                Guten Tag ${data.salutation} ${data.lastName},
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 20px;">
                wir hoffen, Sie sind gut ins neue Jahr gestartet! Als geschätzter Partner der <strong>Maklerplan GmbH</strong> möchten wir Sie herzlich zu unserem <strong>Neujahres-Update 2026</strong> einladen.
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 30px;">
                In diesem exklusiven Gespräch erwartet Sie:
              </p>
              
              <ul style="color: #374151; font-size: 16px; line-height: 1.8; margin: 0 0 30px; padding-left: 20px;">
                <li>Rückblick auf unsere Zusammenarbeit in 2025</li>
                <li>Vorstellung neuer Features & Verbesserungen</li>
                <li>Ihr persönliches Feedback & Wünsche</li>
                <li>Ausblick auf spannende Entwicklungen in 2026</li>
              </ul>
              
              <!-- Meeting Details Box -->
              <table width="100%" style="background-color: #f0f9ff; border-radius: 12px; margin: 30px 0;">
                <tr>
                  <td style="padding: 25px;">
                    <h2 style="color: #1e40af; margin: 0 0 20px; font-size: 18px;">
                      📅 Ihre Termindetails
                    </h2>
                    
                    <table width="100%">
                      <tr>
                        <td width="40" style="vertical-align: top; padding: 8px 0;">
                          <span style="font-size: 20px;">📆</span>
                        </td>
                        <td style="padding: 8px 0;">
                          <strong style="color: #1e40af;">Datum:</strong><br>
                          <span style="color: #374151;">${data.meetingDateFormatted}</span>
                        </td>
                      </tr>
                      <tr>
                        <td width="40" style="vertical-align: top; padding: 8px 0;">
                          <span style="font-size: 20px;">🕐</span>
                        </td>
                        <td style="padding: 8px 0;">
                          <strong style="color: #1e40af;">Uhrzeit:</strong><br>
                          <span style="color: #374151;">${data.meetingTime} Uhr (ca. 30 Minuten)</span>
                        </td>
                      </tr>
                      <tr>
                        <td width="40" style="vertical-align: top; padding: 8px 0;">
                          <span style="font-size: 20px;">👥</span>
                        </td>
                        <td style="padding: 8px 0;">
                          <strong style="color: #1e40af;">Ihre Gesprächspartner:</strong><br>
                          <span style="color: #374151;">Herbert Nicklaus & Dominik Eisenhardt</span>
                        </td>
                      </tr>
                      <tr>
                        <td width="40" style="vertical-align: top; padding: 8px 0;">
                          <span style="font-size: 20px;">💻</span>
                        </td>
                        <td style="padding: 8px 0;">
                          <strong style="color: #1e40af;">Format:</strong><br>
                          <span style="color: #374151;">Zoom Video-Meeting</span>
                        </td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
              
              <!-- CTA Button -->
              <table width="100%" style="margin: 30px 0;">
                <tr>
                  <td align="center">
                    <a href="${data.zoomJoinUrl}" style="display: inline-block; background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); color: #ffffff; text-decoration: none; padding: 16px 40px; border-radius: 8px; font-size: 16px; font-weight: 600; box-shadow: 0 4px 14px rgba(30, 64, 175, 0.4);">
                      🎥 Meeting beitreten
                    </a>
                  </td>
                </tr>
              </table>
              
              <p style="color: #6b7280; font-size: 14px; line-height: 1.6; margin: 20px 0; padding: 15px; background-color: #f9fafb; border-radius: 8px;">
                <strong>Meeting-ID:</strong> ${data.zoomMeetingId}<br>
                <strong>Passwort:</strong> ${data.zoomPassword || 'Wird automatisch angewendet'}
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 30px 0 0;">
                Wir freuen uns auf den Austausch mit Ihnen!
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 20px 0 0;">
                Mit freundlichen Grüßen<br><br>
                <strong>Herbert Nicklaus & Dominik Eisenhardt</strong><br>
                <span style="color: #6b7280;">Maklerplan GmbH</span>
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #f9fafb; padding: 30px 40px; border-top: 1px solid #e5e7eb;">
              <table width="100%">
                <tr>
                  <td>
                    <p style="color: #6b7280; font-size: 14px; margin: 0 0 10px;">
                      <strong>Maklerplan GmbH</strong>
                    </p>
                    <p style="color: #9ca3af; font-size: 13px; margin: 0; line-height: 1.6;">
                      ${process.env.COMPANY_STREET || 'Musterstraße 123'}<br>
                      ${process.env.COMPANY_CITY || '12345 Musterstadt'}<br>
                      📞 ${process.env.COMPANY_PHONE || '+49 123 456789'}<br>
                      🌐 <a href="${process.env.COMPANY_WEBSITE || 'https://www.maklerplan.de'}" style="color: #3b82f6; text-decoration: none;">www.maklerplan.de</a>
                    </p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          
        </table>
        
        <!-- Unsubscribe -->
        <p style="color: #9ca3af; font-size: 12px; margin: 20px 0 0; text-align: center;">
          Sie erhalten diese E-Mail als Partner der Maklerplan GmbH.<br>
          <a href="${data.unsubscribeUrl || '#'}" style="color: #6b7280;">Kommunikationseinstellungen verwalten</a>
        </p>
      </td>
    </tr>
  </table>
</body>
</html>
    `,
    text: `
Neujahres-Update 2026 - Maklerplan GmbH

Guten Tag ${data.salutation} ${data.lastName},

wir hoffen, Sie sind gut ins neue Jahr gestartet! Als geschätzter Partner der Maklerplan GmbH möchten wir Sie herzlich zu unserem Neujahres-Update 2026 einladen.

IHRE TERMINDETAILS
==================
📆 Datum: ${data.meetingDateFormatted}
🕐 Uhrzeit: ${data.meetingTime} Uhr (ca. 30 Minuten)
👥 Gesprächspartner: Herbert Nicklaus & Dominik Eisenhardt
💻 Format: Zoom Video-Meeting

MEETING BEITRETEN
=================
Link: ${data.zoomJoinUrl}
Meeting-ID: ${data.zoomMeetingId}
Passwort: ${data.zoomPassword || 'Wird automatisch angewendet'}

In diesem exklusiven Gespräch erwartet Sie:
• Rückblick auf unsere Zusammenarbeit in 2025
• Vorstellung neuer Features & Verbesserungen
• Ihr persönliches Feedback & Wünsche
• Ausblick auf spannende Entwicklungen in 2026

Wir freuen uns auf den Austausch mit Ihnen!

Mit freundlichen Grüßen
Herbert Nicklaus & Dominik Eisenhardt
Maklerplan GmbH

---
${process.env.COMPANY_STREET || 'Musterstraße 123'}
${process.env.COMPANY_CITY || '12345 Musterstadt'}
Tel: ${process.env.COMPANY_PHONE || '+49 123 456789'}
Web: ${process.env.COMPANY_WEBSITE || 'www.maklerplan.de'}
    `
  }),

  /**
   * REMINDER-EMAIL
   * Wird 1 Tag vor dem Meeting gesendet
   */
  reminder: (data) => ({
    subject: `⏰ Erinnerung: Morgen - Neujahres-Update | ${data.meetingTime} Uhr`,
    html: `
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #f59e0b 0%, #fbbf24 100%); padding: 30px 40px;">
              <h1 style="color: #ffffff; margin: 0; font-size: 24px; font-weight: 600;">
                ⏰ Erinnerung: Morgen ist es soweit!
              </h1>
            </td>
          </tr>
          
          <!-- Body -->
          <tr>
            <td style="padding: 40px;">
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 20px;">
                Guten Tag ${data.salutation} ${data.lastName},
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 30px;">
                wir freuen uns auf unser <strong>Neujahres-Update</strong> mit Ihnen – schon <strong>morgen</strong>!
              </p>
              
              <!-- Quick Info Box -->
              <table width="100%" style="background-color: #fffbeb; border-radius: 12px; border-left: 4px solid #f59e0b;">
                <tr>
                  <td style="padding: 20px;">
                    <p style="margin: 0; color: #92400e; font-size: 18px;">
                      <strong>📆 ${data.meetingDateFormatted}</strong><br>
                      <strong>🕐 ${data.meetingTime} Uhr</strong>
                    </p>
                  </td>
                </tr>
              </table>
              
              <!-- CTA Button -->
              <table width="100%" style="margin: 30px 0;">
                <tr>
                  <td align="center">
                    <a href="${data.zoomJoinUrl}" style="display: inline-block; background: linear-gradient(135deg, #1e40af 0%, #3b82f6 100%); color: #ffffff; text-decoration: none; padding: 16px 40px; border-radius: 8px; font-size: 16px; font-weight: 600;">
                      🎥 Meeting-Link speichern
                    </a>
                  </td>
                </tr>
              </table>
              
              <p style="color: #6b7280; font-size: 14px; text-align: center; margin: 20px 0 0;">
                Meeting-ID: ${data.zoomMeetingId}
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 30px 0 0;">
                Bis morgen!<br><br>
                <strong>Herbert & Dominik</strong><br>
                <span style="color: #6b7280;">Maklerplan GmbH</span>
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `,
    text: `
⏰ ERINNERUNG: Morgen - Neujahres-Update

Guten Tag ${data.salutation} ${data.lastName},

wir freuen uns auf unser Neujahres-Update mit Ihnen – schon morgen!

📆 ${data.meetingDateFormatted}
🕐 ${data.meetingTime} Uhr

Meeting beitreten: ${data.zoomJoinUrl}
Meeting-ID: ${data.zoomMeetingId}

Bis morgen!
Herbert & Dominik
Maklerplan GmbH
    `
  }),

  /**
   * FOLLOW-UP EMAIL
   * Wird 1 Tag nach dem Meeting gesendet
   */
  followUp: (data) => ({
    subject: `Danke für das Gespräch, ${data.firstName}! | Neujahres-Update 2026`,
    html: `
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5;">
  <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background-color: #f5f5f5; padding: 40px 20px;">
    <tr>
      <td align="center">
        <table role="presentation" width="600" cellspacing="0" cellpadding="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #059669 0%, #10b981 100%); padding: 30px 40px;">
              <h1 style="color: #ffffff; margin: 0; font-size: 24px; font-weight: 600;">
                ✅ Vielen Dank für das Gespräch!
              </h1>
            </td>
          </tr>
          
          <!-- Body -->
          <tr>
            <td style="padding: 40px;">
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 20px;">
                Guten Tag ${data.salutation} ${data.lastName},
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 0 0 20px;">
                vielen Dank, dass Sie sich die Zeit für unser <strong>Neujahres-Update</strong> genommen haben! Es war uns eine Freude, mit Ihnen über die Zusammenarbeit in 2025 zu sprechen und Ihnen einen Ausblick auf 2026 zu geben.
              </p>
              
              <!-- Summary Box -->
              <table width="100%" style="background-color: #f0fdf4; border-radius: 12px; margin: 30px 0;">
                <tr>
                  <td style="padding: 25px;">
                    <h2 style="color: #059669; margin: 0 0 15px; font-size: 18px;">
                      📋 Zusammenfassung
                    </h2>
                    <p style="color: #374151; font-size: 15px; line-height: 1.8; margin: 0;">
                      ${data.meetingSummary || 'Die Meeting-Zusammenfassung wird Ihnen in Kürze separat zugesendet.'}
                    </p>
                  </td>
                </tr>
              </table>
              
              ${data.actionItems ? `
              <!-- Action Items -->
              <table width="100%" style="background-color: #fef3c7; border-radius: 12px; margin: 30px 0;">
                <tr>
                  <td style="padding: 25px;">
                    <h2 style="color: #92400e; margin: 0 0 15px; font-size: 18px;">
                      📌 Nächste Schritte
                    </h2>
                    <ul style="color: #374151; font-size: 15px; line-height: 1.8; margin: 0; padding-left: 20px;">
                      ${data.actionItems.map(item => `<li>${item}</li>`).join('')}
                    </ul>
                  </td>
                </tr>
              </table>
              ` : ''}
              
              ${data.recordingUrl ? `
              <!-- Recording Link -->
              <table width="100%" style="margin: 30px 0;">
                <tr>
                  <td align="center">
                    <a href="${data.recordingUrl}" style="display: inline-block; background-color: #f3f4f6; color: #374151; text-decoration: none; padding: 14px 30px; border-radius: 8px; font-size: 15px;">
                      🎬 Meeting-Aufzeichnung ansehen
                    </a>
                  </td>
                </tr>
              </table>
              ` : ''}
              
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 30px 0 20px;">
                Bei Fragen stehen wir Ihnen jederzeit zur Verfügung. Wir freuen uns auf die weitere Zusammenarbeit in 2026!
              </p>
              
              <p style="color: #374151; font-size: 16px; line-height: 1.6; margin: 20px 0 0;">
                Herzliche Grüße<br><br>
                <strong>Herbert Nicklaus & Dominik Eisenhardt</strong><br>
                <span style="color: #6b7280;">Maklerplan GmbH</span>
              </p>
            </td>
          </tr>
          
          <!-- Footer -->
          <tr>
            <td style="background-color: #f9fafb; padding: 30px 40px; border-top: 1px solid #e5e7eb;">
              <p style="color: #9ca3af; font-size: 13px; margin: 0; text-align: center;">
                📞 ${process.env.COMPANY_PHONE || '+49 123 456789'} &nbsp;|&nbsp; 
                ✉️ info@maklerplan.de &nbsp;|&nbsp; 
                🌐 <a href="${process.env.COMPANY_WEBSITE || 'https://www.maklerplan.de'}" style="color: #3b82f6; text-decoration: none;">www.maklerplan.de</a>
              </p>
            </td>
          </tr>
          
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `,
    text: `
✅ Vielen Dank für das Gespräch!

Guten Tag ${data.salutation} ${data.lastName},

vielen Dank, dass Sie sich die Zeit für unser Neujahres-Update genommen haben!

${data.meetingSummary ? `ZUSAMMENFASSUNG:\n${data.meetingSummary}\n` : ''}
${data.actionItems ? `NÄCHSTE SCHRITTE:\n${data.actionItems.map(i => `• ${i}`).join('\n')}\n` : ''}
${data.recordingUrl ? `AUFZEICHNUNG: ${data.recordingUrl}\n` : ''}

Bei Fragen stehen wir Ihnen jederzeit zur Verfügung!

Herzliche Grüße
Herbert Nicklaus & Dominik Eisenhardt
Maklerplan GmbH

Tel: ${process.env.COMPANY_PHONE || '+49 123 456789'}
Web: ${process.env.COMPANY_WEBSITE || 'www.maklerplan.de'}
    `
  })
};

module.exports = { emailTemplates };
