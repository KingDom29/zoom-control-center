/**
 * Maklerplan Campaign API Routes
 * REST Endpoints für Kampagnen-Management
 */

const express = require('express');
const router = express.Router();
const multer = require('multer');
const csv = require('csv-parser');
const { Readable } = require('stream');

// Multer für File Upload
const upload = multer({ storage: multer.memoryStorage() });

/**
 * Factory-Funktion für Routes
 */
function createCampaignRoutes(campaignManager) {

  /**
   * GET /campaign/config
   * Aktuelle Kampagnen-Konfiguration
   */
  router.get('/config', (req, res) => {
    res.json(campaignManager.getConfig());
  });

  /**
   * GET /campaign/stats
   * Kampagnen-Statistiken
   */
  router.get('/stats', (req, res) => {
    res.json(campaignManager.getStats());
  });

  /**
   * GET /campaign/contacts
   * Alle Kontakte abrufen
   */
  router.get('/contacts', (req, res) => {
    const { status } = req.query;
    let contacts = campaignManager.contacts;
    
    if (status) {
      contacts = contacts.filter(c => c.status === status);
    }

    res.json({
      count: contacts.length,
      contacts
    });
  });

  /**
   * POST /campaign/contacts
   * Kontakte laden (JSON)
   */
  router.post('/contacts', (req, res) => {
    try {
      const { contacts } = req.body;
      
      if (!Array.isArray(contacts)) {
        return res.status(400).json({ error: 'contacts muss ein Array sein' });
      }

      const result = campaignManager.loadContacts(contacts);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /campaign/contacts/upload
   * CSV-Upload für Kontakte
   */
  router.post('/contacts/upload', upload.single('file'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'Keine Datei hochgeladen' });
      }

      const contacts = [];
      const stream = Readable.from(req.file.buffer.toString());

      await new Promise((resolve, reject) => {
        stream
          .pipe(csv({ separator: ';' }))
          .on('data', (row) => contacts.push(row))
          .on('end', resolve)
          .on('error', reject);
      });

      const result = campaignManager.loadContacts(contacts);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /campaign/meetings
   * Geplante Meetings abrufen
   */
  router.get('/meetings', (req, res) => {
    res.json({
      count: campaignManager.scheduledMeetings.length,
      meetings: campaignManager.scheduledMeetings.map(m => ({
        contact: {
          name: `${m.contact.firstName} ${m.contact.lastName}`,
          email: m.contact.email,
          company: m.contact.company,
          status: m.contact.status
        },
        slot: m.slot,
        zoomMeetingId: m.zoomMeetingId,
        zoomJoinUrl: m.zoomJoinUrl,
        invitationSent: m.invitationSent,
        reminderSent: m.reminderSent,
        followUpSent: m.followUpSent
      }))
    });
  });

  /**
   * POST /campaign/schedule
   * Alle Meetings planen
   */
  router.post('/schedule', async (req, res) => {
    try {
      const result = await campaignManager.scheduleAllMeetings();
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /campaign/send-invitations
   * Alle Einladungen senden
   */
  router.post('/send-invitations', async (req, res) => {
    try {
      const result = await campaignManager.sendAllInvitations();
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /campaign/send-reminders
   * Fällige Reminder senden
   */
  router.post('/send-reminders', async (req, res) => {
    try {
      const result = await campaignManager.sendDueReminders();
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /campaign/send-followups
   * Fällige Follow-Ups senden
   */
  router.post('/send-followups', async (req, res) => {
    try {
      const result = await campaignManager.sendDueFollowUps();
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * POST /campaign/run
   * Komplette Kampagne starten
   */
  router.post('/run', async (req, res) => {
    try {
      const result = await campaignManager.runFullCampaign();
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /campaign/export/csv
   * Meetings als CSV exportieren
   */
  router.get('/export/csv', (req, res) => {
    const csv = campaignManager.exportMeetingsCSV();
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename=neujahres-update-2026.csv');
    res.send(csv);
  });

  /**
   * GET /campaign/export/ics
   * Meetings als ICS-Kalender exportieren
   */
  router.get('/export/ics', (req, res) => {
    const ics = campaignManager.exportCalendarICS();
    res.setHeader('Content-Type', 'text/calendar');
    res.setHeader('Content-Disposition', 'attachment; filename=neujahres-update-2026.ics');
    res.send(ics);
  });

  /**
   * POST /campaign/email/test
   * Test-E-Mail senden
   */
  router.post('/email/test', async (req, res) => {
    try {
      const { emailService } = require('../services/emailService');
      const { to } = req.body;
      
      if (!to) {
        return res.status(400).json({ error: 'E-Mail-Adresse erforderlich' });
      }

      const result = await emailService.sendTestEmail(to);
      res.json(result);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  });

  /**
   * GET /campaign/email/stats
   * E-Mail-Statistiken
   */
  router.get('/email/stats', (req, res) => {
    const { emailService } = require('../services/emailService');
    res.json(emailService.getStats());
  });

  /**
   * GET /campaign/preview/slots
   * Verfügbare Slots vorschauen
   */
  router.get('/preview/slots', (req, res) => {
    const { limit = 50 } = req.query;
    const slots = campaignManager.scheduler?.generateAvailableSlots(parseInt(limit)) || [];
    res.json({
      count: slots.length,
      slots
    });
  });

  return router;
}

module.exports = { createCampaignRoutes };
