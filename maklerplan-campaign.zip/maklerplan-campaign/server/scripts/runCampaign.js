#!/usr/bin/env node
/**
 * Maklerplan Kampagne - Quick Start Script
 * Lädt Kontakte und startet die Kampagne
 */

const fs = require('fs');
const path = require('path');
const csv = require('csv-parser');

const API_BASE = process.env.API_URL || 'http://localhost:3001';

async function runCampaign() {
  console.log('\n🚀 MAKLERPLAN NEUJAHRES-UPDATE 2026\n');
  console.log('═'.repeat(50));

  // 1. Kontakte aus CSV laden
  console.log('\n📋 Lade Kontakte...');
  
  const csvPath = process.argv[2] || path.join(__dirname, '../data/kontakte-beispiel.csv');
  
  if (!fs.existsSync(csvPath)) {
    console.error(`❌ CSV-Datei nicht gefunden: ${csvPath}`);
    process.exit(1);
  }

  const contacts = [];
  
  await new Promise((resolve, reject) => {
    fs.createReadStream(csvPath)
      .pipe(csv({ separator: ';' }))
      .on('data', (row) => contacts.push(row))
      .on('end', resolve)
      .on('error', reject);
  });

  console.log(`   ✅ ${contacts.length} Kontakte geladen`);

  // 2. Kontakte an API senden
  console.log('\n📤 Sende Kontakte an Server...');
  
  const loadResponse = await fetch(`${API_BASE}/api/campaign/contacts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ contacts })
  });
  
  const loadResult = await loadResponse.json();
  console.log(`   ✅ ${loadResult.loaded} Kontakte registriert`);

  // 3. Meetings planen
  console.log('\n📅 Plane Meetings...');
  
  const scheduleResponse = await fetch(`${API_BASE}/api/campaign/schedule`, {
    method: 'POST'
  });
  
  const scheduleResult = await scheduleResponse.json();
  console.log(`   ✅ ${scheduleResult.scheduled} Meetings erstellt`);

  // 4. Einladungen senden
  console.log('\n📧 Sende Einladungen...');
  
  const inviteResponse = await fetch(`${API_BASE}/api/campaign/send-invitations`, {
    method: 'POST'
  });
  
  const inviteResult = await inviteResponse.json();
  console.log(`   ✅ ${inviteResult.sent} Einladungen gesendet`);

  // 5. Statistiken anzeigen
  console.log('\n📊 Kampagnen-Statistiken:');
  
  const statsResponse = await fetch(`${API_BASE}/api/campaign/stats`);
  const stats = await statsResponse.json();
  
  console.log(`
   Kontakte gesamt:    ${stats.contacts.total}
   Meetings erstellt:  ${stats.meetingsCreated}
   Einladungen:        ${stats.invitationsSent}
   Fehler:             ${stats.errors.length}
  `);

  console.log('\n✅ Kampagne erfolgreich gestartet!\n');
  console.log('═'.repeat(50));
  console.log('\nNächste Schritte:');
  console.log('• Meetings: GET http://localhost:3001/api/campaign/meetings');
  console.log('• CSV Export: GET http://localhost:3001/api/campaign/export/csv');
  console.log('• Kalender: GET http://localhost:3001/api/campaign/export/ics');
}

runCampaign().catch(error => {
  console.error('❌ Fehler:', error.message);
  process.exit(1);
});
