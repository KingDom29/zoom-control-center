/**
 * Campaign Dashboard Component
 * React UI für die Neujahres-Kampagne
 */

import React, { useState, useEffect, useCallback } from 'react';

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3001';

export function CampaignDashboard() {
  const [config, setConfig] = useState(null);
  const [stats, setStats] = useState(null);
  const [contacts, setContacts] = useState([]);
  const [meetings, setMeetings] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [csvFile, setCsvFile] = useState(null);

  // Daten laden
  const fetchData = useCallback(async () => {
    try {
      const [configRes, statsRes, contactsRes, meetingsRes] = await Promise.all([
        fetch(`${API_BASE}/api/campaign/config`),
        fetch(`${API_BASE}/api/campaign/stats`),
        fetch(`${API_BASE}/api/campaign/contacts`),
        fetch(`${API_BASE}/api/campaign/meetings`)
      ]);

      setConfig(await configRes.json());
      setStats(await statsRes.json());
      setContacts((await contactsRes.json()).contacts || []);
      setMeetings((await meetingsRes.json()).meetings || []);
    } catch (error) {
      console.error('Fehler beim Laden:', error);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // CSV Upload
  const handleCsvUpload = async () => {
    if (!csvFile) return;
    
    setLoading(true);
    const formData = new FormData();
    formData.append('file', csvFile);

    try {
      const res = await fetch(`${API_BASE}/api/campaign/contacts/upload`, {
        method: 'POST',
        body: formData
      });
      const result = await res.json();
      alert(`✅ ${result.loaded} Kontakte geladen`);
      fetchData();
    } catch (error) {
      alert('❌ Fehler: ' + error.message);
    }
    setLoading(false);
  };

  // Aktion ausführen
  const runAction = async (action, label) => {
    if (!confirm(`${label} starten?`)) return;
    
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/api/campaign/${action}`, { method: 'POST' });
      const result = await res.json();
      alert(`✅ ${label} abgeschlossen`);
      console.log(result);
      fetchData();
    } catch (error) {
      alert('❌ Fehler: ' + error.message);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-700 to-indigo-800 text-white py-8 px-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold">🎉 Neujahres-Update 2026</h1>
          <p className="text-blue-200 mt-2">Maklerplan GmbH – Kampagnen-Management</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
            <StatCard 
              label="Kontakte" 
              value={stats.contacts?.total || 0} 
              icon="👥" 
              color="blue" 
            />
            <StatCard 
              label="Meetings" 
              value={stats.meetingsCreated || 0} 
              icon="📅" 
              color="green" 
            />
            <StatCard 
              label="Einladungen" 
              value={stats.invitationsSent || 0} 
              icon="📧" 
              color="purple" 
            />
            <StatCard 
              label="Reminder" 
              value={stats.remindersSent || 0} 
              icon="⏰" 
              color="orange" 
            />
            <StatCard 
              label="Follow-Ups" 
              value={stats.followUpsSent || 0} 
              icon="✅" 
              color="teal" 
            />
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
          <div className="border-b border-gray-200">
            <nav className="flex">
              {['overview', 'contacts', 'meetings', 'actions'].map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === tab
                      ? 'border-blue-600 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  {tab === 'overview' && '📊 Übersicht'}
                  {tab === 'contacts' && '👥 Kontakte'}
                  {tab === 'meetings' && '📅 Meetings'}
                  {tab === 'actions' && '⚡ Aktionen'}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {/* Overview Tab */}
            {activeTab === 'overview' && config && (
              <div className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="bg-gray-50 rounded-lg p-6">
                    <h3 className="font-semibold text-gray-900 mb-4">📋 Kampagnen-Info</h3>
                    <dl className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <dt className="text-gray-500">Name:</dt>
                        <dd className="font-medium">{config.campaign?.name}</dd>
                      </div>
                      <div className="flex justify-between">
                        <dt className="text-gray-500">Start:</dt>
                        <dd className="font-medium">{config.campaign?.startDate}</dd>
                      </div>
                      <div className="flex justify-between">
                        <dt className="text-gray-500">Meeting-Zeit:</dt>
                        <dd className="font-medium">{config.meetings?.startHour}:00 - {config.meetings?.endHour}:00</dd>
                      </div>
                      <div className="flex justify-between">
                        <dt className="text-gray-500">Dauer:</dt>
                        <dd className="font-medium">{config.meetings?.duration} Min</dd>
                      </div>
                    </dl>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-6">
                    <h3 className="font-semibold text-gray-900 mb-4">👥 Hosts</h3>
                    {config.hosts?.map((host, i) => (
                      <div key={i} className="flex items-center gap-3 mb-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-semibold">
                          {host.name?.charAt(0)}
                        </div>
                        <div>
                          <p className="font-medium text-gray-900">{host.name}</p>
                          <p className="text-sm text-gray-500">{host.email}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Status Pipeline */}
                {stats?.contacts && (
                  <div className="bg-gray-50 rounded-lg p-6">
                    <h3 className="font-semibold text-gray-900 mb-4">📈 Pipeline</h3>
                    <div className="flex items-center gap-2">
                      <PipelineStep label="Pending" count={stats.contacts.pending} color="gray" />
                      <Arrow />
                      <PipelineStep label="Scheduled" count={stats.contacts.scheduled} color="blue" />
                      <Arrow />
                      <PipelineStep label="Invited" count={stats.contacts.invited} color="purple" />
                      <Arrow />
                      <PipelineStep label="Reminded" count={stats.contacts.reminded} color="orange" />
                      <Arrow />
                      <PipelineStep label="Completed" count={stats.contacts.completed} color="green" />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Contacts Tab */}
            {activeTab === 'contacts' && (
              <div className="space-y-6">
                {/* Upload */}
                <div className="flex items-center gap-4 p-4 bg-blue-50 rounded-lg">
                  <input
                    type="file"
                    accept=".csv"
                    onChange={(e) => setCsvFile(e.target.files[0])}
                    className="flex-1"
                  />
                  <button
                    onClick={handleCsvUpload}
                    disabled={!csvFile || loading}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    {loading ? '...' : '📤 CSV Hochladen'}
                  </button>
                </div>

                {/* Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left">Name</th>
                        <th className="px-4 py-3 text-left">Firma</th>
                        <th className="px-4 py-3 text-left">E-Mail</th>
                        <th className="px-4 py-3 text-left">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {contacts.map((c, i) => (
                        <tr key={i} className="hover:bg-gray-50">
                          <td className="px-4 py-3 font-medium">{c.firstName} {c.lastName}</td>
                          <td className="px-4 py-3 text-gray-600">{c.company}</td>
                          <td className="px-4 py-3 text-gray-600">{c.email}</td>
                          <td className="px-4 py-3">
                            <StatusBadge status={c.status} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {contacts.length === 0 && (
                    <p className="text-center text-gray-500 py-8">Keine Kontakte geladen</p>
                  )}
                </div>
              </div>
            )}

            {/* Meetings Tab */}
            {activeTab === 'meetings' && (
              <div className="space-y-4">
                {meetings.map((m, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        {new Date(m.slot?.dateISO).getDate()}
                      </div>
                      <div className="text-xs text-gray-500">
                        {new Date(m.slot?.dateISO).toLocaleDateString('de-DE', { month: 'short' })}
                      </div>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium">{m.contact?.name}</p>
                      <p className="text-sm text-gray-500">{m.contact?.company}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{m.slot?.timeFormatted} Uhr</p>
                      <StatusBadge status={m.contact?.status} />
                    </div>
                    {m.zoomJoinUrl && (
                      <a 
                        href={m.zoomJoinUrl} 
                        target="_blank" 
                        className="px-3 py-1 bg-blue-100 text-blue-700 rounded-lg text-sm"
                      >
                        🎥 Join
                      </a>
                    )}
                  </div>
                ))}
                {meetings.length === 0 && (
                  <p className="text-center text-gray-500 py-8">Keine Meetings geplant</p>
                )}
              </div>
            )}

            {/* Actions Tab */}
            {activeTab === 'actions' && (
              <div className="grid md:grid-cols-2 gap-4">
                <ActionButton
                  icon="📅"
                  label="Meetings planen"
                  desc="Erstellt Zoom-Meetings für alle Kontakte"
                  onClick={() => runAction('schedule', 'Meetings planen')}
                  disabled={loading || contacts.length === 0}
                  color="blue"
                />
                <ActionButton
                  icon="📧"
                  label="Einladungen senden"
                  desc="Sendet E-Mail-Einladungen an alle"
                  onClick={() => runAction('send-invitations', 'Einladungen senden')}
                  disabled={loading || meetings.length === 0}
                  color="purple"
                />
                <ActionButton
                  icon="⏰"
                  label="Reminder senden"
                  desc="Sendet Erinnerungen für morgige Meetings"
                  onClick={() => runAction('send-reminders', 'Reminder senden')}
                  disabled={loading}
                  color="orange"
                />
                <ActionButton
                  icon="✅"
                  label="Follow-Ups senden"
                  desc="Sendet Dankes-Mails für gestrige Meetings"
                  onClick={() => runAction('send-followups', 'Follow-Ups senden')}
                  disabled={loading}
                  color="green"
                />
                <ActionButton
                  icon="🚀"
                  label="Alles starten"
                  desc="Plant Meetings + sendet alle Einladungen"
                  onClick={() => runAction('run', 'Komplette Kampagne')}
                  disabled={loading || contacts.length === 0}
                  color="red"
                />
                <a
                  href={`${API_BASE}/api/campaign/export/csv`}
                  className="p-4 rounded-lg border-2 border-gray-200 hover:border-gray-300 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-2xl">📥</span>
                    <div>
                      <p className="font-medium text-gray-900">CSV Export</p>
                      <p className="text-sm text-gray-500">Meetings als CSV herunterladen</p>
                    </div>
                  </div>
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// Helper Components
function StatCard({ label, value, icon, color }) {
  const colors = {
    blue: 'bg-blue-50 text-blue-600',
    green: 'bg-green-50 text-green-600',
    purple: 'bg-purple-50 text-purple-600',
    orange: 'bg-orange-50 text-orange-600',
    teal: 'bg-teal-50 text-teal-600'
  };

  return (
    <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-200">
      <div className={`w-10 h-10 rounded-lg ${colors[color]} flex items-center justify-center text-xl mb-3`}>
        {icon}
      </div>
      <p className="text-2xl font-bold text-gray-900">{value}</p>
      <p className="text-sm text-gray-500">{label}</p>
    </div>
  );
}

function StatusBadge({ status }) {
  const styles = {
    pending: 'bg-gray-100 text-gray-600',
    scheduled: 'bg-blue-100 text-blue-700',
    invited: 'bg-purple-100 text-purple-700',
    reminded: 'bg-orange-100 text-orange-700',
    completed: 'bg-green-100 text-green-700'
  };

  return (
    <span className={`px-2 py-1 rounded-full text-xs font-medium ${styles[status] || styles.pending}`}>
      {status || 'pending'}
    </span>
  );
}

function PipelineStep({ label, count, color }) {
  const colors = {
    gray: 'bg-gray-100 border-gray-300',
    blue: 'bg-blue-100 border-blue-300',
    purple: 'bg-purple-100 border-purple-300',
    orange: 'bg-orange-100 border-orange-300',
    green: 'bg-green-100 border-green-300'
  };

  return (
    <div className={`flex-1 p-3 rounded-lg border-2 ${colors[color]} text-center`}>
      <p className="text-2xl font-bold">{count}</p>
      <p className="text-xs text-gray-600">{label}</p>
    </div>
  );
}

function Arrow() {
  return (
    <svg className="w-6 h-6 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
    </svg>
  );
}

function ActionButton({ icon, label, desc, onClick, disabled, color }) {
  const colors = {
    blue: 'border-blue-200 hover:border-blue-400 hover:bg-blue-50',
    purple: 'border-purple-200 hover:border-purple-400 hover:bg-purple-50',
    orange: 'border-orange-200 hover:border-orange-400 hover:bg-orange-50',
    green: 'border-green-200 hover:border-green-400 hover:bg-green-50',
    red: 'border-red-200 hover:border-red-400 hover:bg-red-50'
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`p-4 rounded-lg border-2 ${colors[color]} transition-colors text-left disabled:opacity-50 disabled:cursor-not-allowed`}
    >
      <div className="flex items-center gap-3">
        <span className="text-2xl">{icon}</span>
        <div>
          <p className="font-medium text-gray-900">{label}</p>
          <p className="text-sm text-gray-500">{desc}</p>
        </div>
      </div>
    </button>
  );
}

export default CampaignDashboard;
