# 🚀 Maklerplan Control Center - Neujahres-Update 2026

Automatisiertes Kampagnen-System für Zoom-Meetings mit professionellen E-Mail-Einladungen.

## ✨ Features

- ✅ **Automatische Meeting-Planung** – Mo-Fr, 9-17 Uhr
- ✅ **Professionelle HTML-E-Mails** – Einladung, Reminder, Follow-Up
- ✅ **CSV-Import** – Kontaktliste einfach hochladen
- ✅ **Zoom-Integration** – Meetings automatisch erstellen
- ✅ **Export** – CSV & ICS-Kalender
- ✅ **Dashboard** – Live-Statistiken

---

## 📦 Installation

```bash
cd server
npm install
cp .env.example .env
```

## ⚙️ Konfiguration (.env)

### Zoom API (aus marketplace.zoom.us)
```env
ZOOM_ACCOUNT_ID=dein_account_id
ZOOM_CLIENT_ID=dein_client_id
ZOOM_CLIENT_SECRET=dein_client_secret
```

### E-Mail (SMTP)
```env
SMTP_HOST=smtp.office365.com
SMTP_PORT=587
SMTP_USER=info@maklerplan.de
SMTP_PASSWORD=dein_email_passwort

EMAIL_FROM_NAME=Maklerplan GmbH
EMAIL_FROM_ADDRESS=info@maklerplan.de
```

### Kampagne
```env
CAMPAIGN_NAME=Neujahres-Update 2026
CAMPAIGN_START_DATE=2026-01-19

MEETING_START_HOUR=9
MEETING_END_HOUR=17
MEETING_DURATION_MINUTES=30
MEETING_DAYS=1,2,3,4,5

HOST_1_NAME=Herbert Nicklaus
HOST_1_EMAIL=herbert.nicklaus@maklerplan.de
HOST_2_NAME=Dominik Eisenhardt
HOST_2_EMAIL=dominik.eisenhardt@maklerplan.de
```

---

## 🚀 Quick Start

### 1. Server starten
```bash
npm run dev
```

### 2. Kontakte laden (CSV)
```bash
curl -X POST http://localhost:3001/api/campaign/contacts/upload \
  -F "file=@data/kontakte.csv"
```

Oder JSON:
```bash
curl -X POST http://localhost:3001/api/campaign/contacts \
  -H "Content-Type: application/json" \
  -d '{
    "contacts": [
      {"vorname": "Max", "nachname": "Mustermann", "email": "max@example.de", "firma": "Immo GmbH"},
      {"vorname": "Anna", "nachname": "Schmidt", "email": "anna@example.de", "firma": "Schmidt Makler"}
    ]
  }'
```

### 3. Meetings planen
```bash
curl -X POST http://localhost:3001/api/campaign/schedule
```

### 4. Einladungen senden
```bash
curl -X POST http://localhost:3001/api/campaign/send-invitations
```

### Oder alles in einem Schritt:
```bash
npm run run-campaign data/kontakte.csv
```

---

## 📋 CSV-Format

Die CSV-Datei sollte diese Spalten haben (Semikolon-getrennt):

```csv
Anrede;Vorname;Nachname;Email;Firma;Telefon;Notizen
Herr;Max;Mustermann;max@example.de;Immo GmbH;+49 171 123456;VIP Kunde
Frau;Anna;Schmidt;anna@schmidt.de;Schmidt Makler;+49 172 234567;Neukunde
```

**Unterstützte Spaltenamen:**
- `Anrede` / `salutation`
- `Vorname` / `firstName` / `name`
- `Nachname` / `lastName`
- `Email` / `email` / `mail`
- `Firma` / `company` / `unternehmen`
- `Telefon` / `phone`
- `Notizen` / `notes`

---

## 📡 API Endpoints

### Kampagne

| Endpoint | Methode | Beschreibung |
|----------|---------|--------------|
| `/api/campaign/config` | GET | Konfiguration anzeigen |
| `/api/campaign/stats` | GET | Statistiken |
| `/api/campaign/contacts` | GET | Alle Kontakte |
| `/api/campaign/contacts` | POST | Kontakte laden (JSON) |
| `/api/campaign/contacts/upload` | POST | CSV hochladen |
| `/api/campaign/meetings` | GET | Geplante Meetings |
| `/api/campaign/schedule` | POST | Meetings planen |
| `/api/campaign/send-invitations` | POST | Einladungen senden |
| `/api/campaign/send-reminders` | POST | Reminder senden |
| `/api/campaign/send-followups` | POST | Follow-Ups senden |
| `/api/campaign/run` | POST | Komplette Kampagne |

### Export

| Endpoint | Methode | Beschreibung |
|----------|---------|--------------|
| `/api/campaign/export/csv` | GET | Meetings als CSV |
| `/api/campaign/export/ics` | GET | Kalender-Export |

### E-Mail

| Endpoint | Methode | Beschreibung |
|----------|---------|--------------|
| `/api/campaign/email/test` | POST | Test-E-Mail senden |
| `/api/campaign/email/stats` | GET | E-Mail Statistiken |

---

## 📧 E-Mail-Ablauf

```
Tag X-7:  📧 Einladung gesendet
Tag X-1:  ⏰ Reminder gesendet
Tag X:    🎥 Meeting findet statt
Tag X+1:  ✅ Follow-Up gesendet
```

---

## 🗓️ Meeting-Verteilung

Meetings werden automatisch auf verfügbare Slots verteilt:

```
Montag    9:00  │ Meeting 1 – Mustermann
          9:45  │ Meeting 2 – Schmidt
         10:30  │ Meeting 3 – Weber
         ...
         16:15  │ Meeting 16 – Meier

Dienstag  9:00  │ Meeting 17 – Bauer
          ...
```

**Berechnung:**
- Slots pro Tag: `(17-9) * 60 / (30+15)` = **~10-11 Meetings/Tag**
- 20 Kontakte = **~2 Arbeitstage**

---

## 🧪 Testen

### Test-E-Mail senden
```bash
curl -X POST http://localhost:3001/api/campaign/email/test \
  -H "Content-Type: application/json" \
  -d '{"to": "deine-email@example.de"}'
```

### Env-Check
```bash
curl http://localhost:3001/api/env-check
```

### Verfügbare Slots vorschauen
```bash
curl http://localhost:3001/api/campaign/preview/slots?limit=20
```

---

## 📁 Projektstruktur

```
maklerplan-campaign/
├── server/
│   ├── index.js                 # Main Server
│   ├── services/
│   │   ├── campaignManager.js   # Kampagnen-Orchestrierung
│   │   ├── meetingScheduler.js  # Meeting-Planung
│   │   └── emailService.js      # E-Mail-Versand
│   ├── routes/
│   │   └── campaignRoutes.js    # API Endpoints
│   ├── templates/
│   │   └── emailTemplates.js    # HTML E-Mail Templates
│   ├── scripts/
│   │   └── runCampaign.js       # Quick Start Script
│   ├── package.json
│   └── .env.example
│
└── data/
    └── kontakte-beispiel.csv    # Beispiel-Kontaktliste
```

---

## 🔒 Sicherheit

- ✅ E-Mail-Credentials nur in `.env`
- ✅ SMTP über TLS
- ✅ Zoom OAuth2 statt API Keys
- ✅ Rate Limiting bei E-Mail-Versand (2s Pause)

---

## 🐛 Troubleshooting

### E-Mails werden nicht gesendet
1. Prüfe SMTP-Credentials in `.env`
2. Test-E-Mail senden: `POST /api/campaign/email/test`
3. Prüfe Spam-Ordner

### Zoom-Meetings werden nicht erstellt
1. Prüfe Zoom API Credentials
2. Prüfe Scopes in Zoom Marketplace:
   - `meeting:write:admin`
   - `user:read:admin`

### CSV wird nicht erkannt
- Trennzeichen muss `;` sein
- UTF-8 Encoding
- Erste Zeile = Header

---

## 📞 Support

Bei Fragen: info@maklerplan.de

---

**Made with ❤️ für Maklerplan GmbH**
