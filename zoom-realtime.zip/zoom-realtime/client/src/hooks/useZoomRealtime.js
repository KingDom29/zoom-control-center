/**
 * useZoomRealtime Hook
 * React Hook für WebSocket-Verbindung zu Zoom Echtzeit-Events
 */

import { useState, useEffect, useCallback, useRef } from 'react';

const WS_URL = import.meta.env.VITE_WS_URL || 'ws://localhost:3001/ws';

export function useZoomRealtime(options = {}) {
  const {
    autoConnect = true,
    reconnectInterval = 3000,
    maxReconnectAttempts = 10,
    subscriptions = ['*'], // Default: alle Events
    onEvent,
    onConnect,
    onDisconnect,
    onError
  } = options;

  const [isConnected, setIsConnected] = useState(false);
  const [events, setEvents] = useState([]);
  const [connectionStatus, setConnectionStatus] = useState('disconnected');
  const [clientId, setClientId] = useState(null);
  const [stats, setStats] = useState({ connectedClients: 0 });

  const wsRef = useRef(null);
  const reconnectAttempts = useRef(0);
  const reconnectTimeoutRef = useRef(null);

  // Verbindung aufbauen
  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return;
    }

    setConnectionStatus('connecting');
    console.log('🔌 Verbinde zu WebSocket...');

    try {
      wsRef.current = new WebSocket(WS_URL);

      wsRef.current.onopen = () => {
        console.log('✅ WebSocket verbunden');
        setIsConnected(true);
        setConnectionStatus('connected');
        reconnectAttempts.current = 0;

        // Subscriptions senden
        if (subscriptions.length > 0 && !subscriptions.includes('*')) {
          wsRef.current.send(JSON.stringify({
            type: 'subscribe',
            events: subscriptions
          }));
        }

        onConnect?.();
      };

      wsRef.current.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          handleMessage(message);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

      wsRef.current.onclose = (event) => {
        console.log('❌ WebSocket geschlossen:', event.code);
        setIsConnected(false);
        setConnectionStatus('disconnected');
        setClientId(null);
        onDisconnect?.();

        // Auto-Reconnect
        if (reconnectAttempts.current < maxReconnectAttempts) {
          reconnectAttempts.current++;
          setConnectionStatus('reconnecting');
          reconnectTimeoutRef.current = setTimeout(() => {
            console.log(`🔄 Reconnect Versuch ${reconnectAttempts.current}/${maxReconnectAttempts}`);
            connect();
          }, reconnectInterval);
        }
      };

      wsRef.current.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnectionStatus('error');
        onError?.(error);
      };

    } catch (error) {
      console.error('Failed to create WebSocket:', error);
      setConnectionStatus('error');
    }
  }, [subscriptions, onConnect, onDisconnect, onError, reconnectInterval, maxReconnectAttempts]);

  // Nachricht verarbeiten
  const handleMessage = useCallback((message) => {
    switch (message.type) {
      case 'connection':
        setClientId(message.clientId);
        break;

      case 'event':
        const newEvent = {
          ...message.data,
          receivedAt: new Date().toISOString()
        };
        
        setEvents(prev => [newEvent, ...prev].slice(0, 100)); // Max 100 Events
        onEvent?.(newEvent);
        break;

      case 'stats':
        setStats(message);
        break;

      case 'subscribed':
        console.log('Subscribed to:', message.events);
        break;

      case 'pong':
        // Heartbeat response
        break;

      default:
        console.log('Unknown message type:', message.type);
    }
  }, [onEvent]);

  // Verbindung trennen
  const disconnect = useCallback(() => {
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }
    reconnectAttempts.current = maxReconnectAttempts; // Verhindert Reconnect
    
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setIsConnected(false);
    setConnectionStatus('disconnected');
  }, [maxReconnectAttempts]);

  // Nachricht senden
  const send = useCallback((data) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(data));
    }
  }, []);

  // Zu Event-Typen subscriben
  const subscribe = useCallback((eventTypes) => {
    send({ type: 'subscribe', events: Array.isArray(eventTypes) ? eventTypes : [eventTypes] });
  }, [send]);

  // Event-Typen abbestellen
  const unsubscribe = useCallback((eventTypes) => {
    send({ type: 'unsubscribe', events: Array.isArray(eventTypes) ? eventTypes : [eventTypes] });
  }, [send]);

  // Einem Meeting-Room beitreten für spezifische Updates
  const joinMeetingRoom = useCallback((meetingId) => {
    send({ type: 'join_room', room: `meeting:${meetingId}` });
  }, [send]);

  // Meeting-Room verlassen
  const leaveMeetingRoom = useCallback((meetingId) => {
    send({ type: 'leave_room', room: `meeting:${meetingId}` });
  }, [send]);

  // Stats anfragen
  const requestStats = useCallback(() => {
    send({ type: 'get_stats' });
  }, [send]);

  // Events löschen
  const clearEvents = useCallback(() => {
    setEvents([]);
  }, []);

  // Auto-Connect beim Mount
  useEffect(() => {
    if (autoConnect) {
      connect();
    }

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (wsRef.current) {
        reconnectAttempts.current = maxReconnectAttempts;
        wsRef.current.close();
      }
    };
  }, [autoConnect, connect, maxReconnectAttempts]);

  return {
    // State
    isConnected,
    connectionStatus,
    clientId,
    events,
    stats,
    
    // Actions
    connect,
    disconnect,
    subscribe,
    unsubscribe,
    joinMeetingRoom,
    leaveMeetingRoom,
    requestStats,
    clearEvents,
    send
  };
}

export default useZoomRealtime;
