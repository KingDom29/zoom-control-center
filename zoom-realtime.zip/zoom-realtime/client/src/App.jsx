/**
 * Demo App - Zoom Control Center mit Echtzeit Events
 * Zeigt alle Komponenten in Aktion
 */

import React, { useState } from 'react';
import { useZoomRealtime } from './hooks/useZoomRealtime';
import { ToastContainer, ConnectionBadge } from './components/ToastNotifications';
import { LiveEventsPanel, LiveEventsMini } from './components/LiveEventsPanel';

function App() {
  const [showPanel, setShowPanel] = useState(true);
  
  const { 
    isConnected, 
    events, 
    connectionStatus,
    stats,
    requestStats,
    clearEvents
  } = useZoomRealtime({
    onEvent: (event) => {
      // Optional: Sound abspielen, Analytics loggen, etc.
      console.log('📩 Event:', event.type);
    }
  });

  // Test-Event senden
  const sendTestEvent = async (eventType) => {
    try {
      await fetch('http://localhost:3001/webhook/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ eventType })
      });
    } catch (error) {
      console.error('Failed to send test event:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Toast Notifications */}
      <ToastContainer position="top-right" maxToasts={5} />

      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M4 4h10v10H4V4zm12 0h4v4h-4V4zm0 6h4v4h-4v-4zm0 6h4v4h-4v-4zm-6 0h4v4h-4v-4zm-6 0h4v4H4v-4z"/>
                  </svg>
                </div>
                <h1 className="text-xl font-bold text-gray-900">Zoom Control Center</h1>
              </div>
              <ConnectionBadge />
            </div>

            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-500">
                {events.length} Events
              </span>
              <button
                onClick={() => setShowPanel(!showPanel)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                {showPanel ? 'Panel ausblenden' : 'Panel einblenden'}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column - Dashboard */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Stats Cards */}
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${isConnected ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'}`}>
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.636 18.364a9 9 0 010-12.728m12.728 0a9 9 0 010 12.728m-9.9-2.829a5 5 0 010-7.07m7.072 0a5 5 0 010 7.07M13 12a1 1 0 11-2 0 1 1 0 012 0z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900">{connectionStatus}</p>
                    <p className="text-sm text-gray-500">Verbindung</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900">{events.length}</p>
                    <p className="text-sm text-gray-500">Events empfangen</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-gray-900">{stats.connectedClients || 1}</p>
                    <p className="text-sm text-gray-500">Clients verbunden</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Test Events Panel */}
            <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">🧪 Test Events senden</h2>
              <p className="text-sm text-gray-500 mb-4">
                Klicke auf einen Button um ein simuliertes Zoom-Event zu senden:
              </p>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => sendTestEvent('meeting.started')}
                  className="px-4 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors text-sm font-medium"
                >
                  🟢 Meeting gestartet
                </button>
                <button
                  onClick={() => sendTestEvent('meeting.ended')}
                  className="px-4 py-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors text-sm font-medium"
                >
                  🔴 Meeting beendet
                </button>
                <button
                  onClick={() => sendTestEvent('meeting.participant_joined')}
                  className="px-4 py-2 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition-colors text-sm font-medium"
                >
                  👋 Teilnehmer beigetreten
                </button>
                <button
                  onClick={() => sendTestEvent('recording.completed')}
                  className="px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors text-sm font-medium"
                >
                  🎬 Aufnahme fertig
                </button>
                <button
                  onClick={() => sendTestEvent('user.created')}
                  className="px-4 py-2 bg-orange-100 text-orange-700 rounded-lg hover:bg-orange-200 transition-colors text-sm font-medium"
                >
                  👤 Neuer Benutzer
                </button>
              </div>
              
              <div className="mt-4 pt-4 border-t border-gray-100 flex gap-2">
                <button
                  onClick={clearEvents}
                  className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                >
                  Events leeren
                </button>
                <button
                  onClick={requestStats}
                  className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm"
                >
                  Stats aktualisieren
                </button>
              </div>
            </div>

            {/* Integration Code */}
            <div className="bg-gray-900 rounded-xl p-6 shadow-sm">
              <h2 className="text-lg font-semibold text-white mb-4">📝 Integration Code</h2>
              <pre className="text-green-400 text-sm overflow-x-auto">
{`// 1. Hook importieren
import { useZoomRealtime } from './hooks/useZoomRealtime';

// 2. In deiner Komponente verwenden
const { events, isConnected } = useZoomRealtime({
  onEvent: (event) => {
    console.log('Neues Event:', event);
  }
});

// 3. Events anzeigen
{events.map(event => (
  <div key={event.id}>
    {event.ui.icon} {event.ui.title}
  </div>
))}`}
              </pre>
            </div>
          </div>

          {/* Right Column - Live Events */}
          <div className="lg:col-span-1">
            {showPanel && <LiveEventsPanel />}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 bg-white mt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <p className="text-sm text-gray-500 text-center">
            Zoom Control Center • WebSocket: ws://localhost:3001/ws • 
            Webhook: http://localhost:3001/webhook/zoom
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;
