/**
 * Live Events Panel
 * Zeigt alle Zoom-Events in Echtzeit als scrollbare Liste
 */

import React, { useState, useMemo } from 'react';
import { useZoomRealtime } from '../hooks/useZoomRealtime';
import { ConnectionBadge } from './ToastNotifications';

export function LiveEventsPanel({ className = '' }) {
  const { 
    events, 
    isConnected, 
    clearEvents,
    stats,
    requestStats 
  } = useZoomRealtime();
  
  const [filter, setFilter] = useState('all');
  const [isExpanded, setIsExpanded] = useState(true);

  // Event-Typen für Filter extrahieren
  const eventTypes = useMemo(() => {
    const types = new Set(events.map(e => e.type));
    return ['all', ...Array.from(types)];
  }, [events]);

  // Gefilterte Events
  const filteredEvents = useMemo(() => {
    if (filter === 'all') return events;
    return events.filter(e => e.type === filter);
  }, [events, filter]);

  // Zeit formatieren
  const formatTime = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString('de-DE', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  // Zeitdifferenz berechnen
  const getTimeAgo = (timestamp) => {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    if (seconds < 60) return `vor ${seconds}s`;
    if (seconds < 3600) return `vor ${Math.floor(seconds / 60)}m`;
    return `vor ${Math.floor(seconds / 3600)}h`;
  };

  return (
    <div className={`bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden ${className}`}>
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-lg">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} 
                  d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <div>
              <h3 className="font-semibold">Live Events</h3>
              <p className="text-sm text-blue-100">{events.length} Events</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <ConnectionBadge />
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors"
            >
              <svg 
                className={`w-5 h-5 transition-transform ${isExpanded ? 'rotate-180' : ''}`} 
                fill="none" stroke="currentColor" viewBox="0 0 24 24"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
          </div>
        </div>

        {/* Filter & Actions */}
        {isExpanded && (
          <div className="mt-4 flex items-center gap-2 flex-wrap">
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="bg-white/20 border-0 rounded-lg text-sm py-1.5 px-3 text-white placeholder-blue-200 focus:ring-2 focus:ring-white/50"
            >
              {eventTypes.map(type => (
                <option key={type} value={type} className="text-gray-900">
                  {type === 'all' ? 'Alle Events' : type}
                </option>
              ))}
            </select>
            
            <button
              onClick={clearEvents}
              className="bg-white/20 hover:bg-white/30 text-sm py-1.5 px-3 rounded-lg transition-colors"
            >
              Leeren
            </button>
            
            <button
              onClick={requestStats}
              className="bg-white/20 hover:bg-white/30 text-sm py-1.5 px-3 rounded-lg transition-colors"
            >
              🔄 Stats
            </button>
          </div>
        )}
      </div>

      {/* Events Liste */}
      {isExpanded && (
        <div className="max-h-[500px] overflow-y-auto">
          {filteredEvents.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gray-100 flex items-center justify-center">
                <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} 
                    d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                </svg>
              </div>
              <p className="font-medium">Keine Events</p>
              <p className="text-sm">Events werden hier live angezeigt</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-100">
              {filteredEvents.map((event, index) => (
                <EventItem key={event.id || index} event={event} formatTime={formatTime} getTimeAgo={getTimeAgo} />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// Einzelnes Event Item
function EventItem({ event, formatTime, getTimeAgo }) {
  const [isExpanded, setIsExpanded] = useState(false);
  
  const ui = event.ui || {
    icon: '📌',
    title: event.type,
    message: 'Event empfangen',
    color: 'gray'
  };

  const colorClasses = {
    green: 'bg-green-100 text-green-600',
    red: 'bg-red-100 text-red-600',
    blue: 'bg-blue-100 text-blue-600',
    purple: 'bg-purple-100 text-purple-600',
    orange: 'bg-orange-100 text-orange-600',
    gray: 'bg-gray-100 text-gray-600'
  };

  const bgColor = colorClasses[ui.color] || colorClasses.gray;

  return (
    <div 
      className="p-4 hover:bg-gray-50 cursor-pointer transition-colors"
      onClick={() => setIsExpanded(!isExpanded)}
    >
      <div className="flex items-start gap-3">
        {/* Icon */}
        <div className={`flex-shrink-0 w-10 h-10 rounded-lg ${bgColor} flex items-center justify-center text-lg`}>
          {ui.icon}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <p className="font-medium text-gray-900 truncate">{ui.title}</p>
            <span className="text-xs text-gray-500 flex-shrink-0">
              {getTimeAgo(event.timestamp)}
            </span>
          </div>
          <p className="text-sm text-gray-600 truncate">{ui.message}</p>
          
          {/* Event Type Badge */}
          <span className="inline-block mt-1 text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">
            {event.type}
          </span>
        </div>

        {/* Expand Icon */}
        <svg 
          className={`w-5 h-5 text-gray-400 transition-transform ${isExpanded ? 'rotate-180' : ''}`}
          fill="none" stroke="currentColor" viewBox="0 0 24 24"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </div>

      {/* Expanded Details */}
      {isExpanded && (
        <div className="mt-3 ml-13 p-3 bg-gray-50 rounded-lg text-xs">
          <div className="grid grid-cols-2 gap-2">
            <div>
              <span className="text-gray-500">Event ID:</span>
              <span className="ml-2 font-mono">{event.id?.slice(0, 8)}...</span>
            </div>
            <div>
              <span className="text-gray-500">Zeit:</span>
              <span className="ml-2">{formatTime(event.timestamp)}</span>
            </div>
            {ui.meetingId && (
              <div className="col-span-2">
                <span className="text-gray-500">Meeting ID:</span>
                <span className="ml-2 font-mono">{ui.meetingId}</span>
              </div>
            )}
          </div>
          
          {/* Raw Payload Toggle */}
          <details className="mt-2">
            <summary className="text-gray-500 cursor-pointer hover:text-gray-700">
              Raw Payload anzeigen
            </summary>
            <pre className="mt-2 p-2 bg-gray-900 text-green-400 rounded overflow-x-auto text-xs">
              {JSON.stringify(event.payload, null, 2)}
            </pre>
          </details>
        </div>
      )}
    </div>
  );
}

// Mini-Version für Sidebar
export function LiveEventsMini({ maxEvents = 5 }) {
  const { events, isConnected } = useZoomRealtime();
  const recentEvents = events.slice(0, maxEvents);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium text-gray-700">Live Activity</h4>
        <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500' : 'bg-gray-400'}`} />
      </div>
      
      {recentEvents.length === 0 ? (
        <p className="text-xs text-gray-500">Keine aktuellen Events</p>
      ) : (
        <div className="space-y-1">
          {recentEvents.map((event, i) => (
            <div key={event.id || i} className="flex items-center gap-2 text-xs">
              <span>{event.ui?.icon || '📌'}</span>
              <span className="truncate text-gray-600">{event.ui?.title || event.type}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default LiveEventsPanel;
