/**
 * Zoom Event Toast Notifications
 * Zeigt Echtzeit-Benachrichtigungen als Toast-Popups
 */

import React, { useState, useEffect, useCallback } from 'react';
import { useZoomRealtime } from '../hooks/useZoomRealtime';

// Toast Container Component
export function ToastContainer({ position = 'top-right', maxToasts = 5 }) {
  const [toasts, setToasts] = useState([]);
  
  const { events } = useZoomRealtime({
    onEvent: (event) => {
      addToast(event);
    }
  });

  const addToast = useCallback((event) => {
    const toast = {
      id: event.id || Date.now(),
      ...event.ui,
      timestamp: event.timestamp,
      dismissed: false
    };

    setToasts(prev => [toast, ...prev].slice(0, maxToasts));

    // Auto-dismiss nach 5 Sekunden
    setTimeout(() => {
      dismissToast(toast.id);
    }, 5000);
  }, [maxToasts]);

  const dismissToast = useCallback((id) => {
    setToasts(prev => prev.map(t => 
      t.id === id ? { ...t, dismissed: true } : t
    ));
    
    // Nach Animation entfernen
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 300);
  }, []);

  const positionClasses = {
    'top-right': 'top-4 right-4',
    'top-left': 'top-4 left-4',
    'bottom-right': 'bottom-4 right-4',
    'bottom-left': 'bottom-4 left-4',
    'top-center': 'top-4 left-1/2 -translate-x-1/2',
    'bottom-center': 'bottom-4 left-1/2 -translate-x-1/2'
  };

  return (
    <div className={`fixed ${positionClasses[position]} z-50 flex flex-col gap-2 pointer-events-none`}>
      {toasts.map(toast => (
        <Toast 
          key={toast.id} 
          toast={toast} 
          onDismiss={() => dismissToast(toast.id)} 
        />
      ))}
    </div>
  );
}

// Einzelner Toast
function Toast({ toast, onDismiss }) {
  const colorClasses = {
    green: 'bg-green-50 border-green-500 text-green-800',
    red: 'bg-red-50 border-red-500 text-red-800',
    blue: 'bg-blue-50 border-blue-500 text-blue-800',
    purple: 'bg-purple-50 border-purple-500 text-purple-800',
    orange: 'bg-orange-50 border-orange-500 text-orange-800',
    gray: 'bg-gray-50 border-gray-500 text-gray-800'
  };

  const baseClass = colorClasses[toast.color] || colorClasses.gray;

  return (
    <div 
      className={`
        pointer-events-auto
        min-w-[320px] max-w-md
        p-4 rounded-lg shadow-lg border-l-4
        transform transition-all duration-300 ease-out
        ${baseClass}
        ${toast.dismissed ? 'opacity-0 translate-x-full' : 'opacity-100 translate-x-0'}
      `}
    >
      <div className="flex items-start gap-3">
        <span className="text-2xl flex-shrink-0">{toast.icon}</span>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm">{toast.title}</p>
          <p className="text-sm opacity-90 truncate">{toast.message}</p>
        </div>
        <button 
          onClick={onDismiss}
          className="flex-shrink-0 opacity-50 hover:opacity-100 transition-opacity"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>
    </div>
  );
}

// Connection Status Badge
export function ConnectionBadge() {
  const { isConnected, connectionStatus } = useZoomRealtime();

  const statusConfig = {
    connected: { color: 'bg-green-500', text: 'Live', pulse: true },
    connecting: { color: 'bg-yellow-500', text: 'Verbinde...', pulse: true },
    reconnecting: { color: 'bg-yellow-500', text: 'Reconnecting...', pulse: true },
    disconnected: { color: 'bg-gray-500', text: 'Offline', pulse: false },
    error: { color: 'bg-red-500', text: 'Fehler', pulse: false }
  };

  const config = statusConfig[connectionStatus] || statusConfig.disconnected;

  return (
    <div className="flex items-center gap-2 text-sm">
      <span className="relative flex h-3 w-3">
        {config.pulse && (
          <span className={`animate-ping absolute inline-flex h-full w-full rounded-full ${config.color} opacity-75`}></span>
        )}
        <span className={`relative inline-flex rounded-full h-3 w-3 ${config.color}`}></span>
      </span>
      <span className="text-gray-600">{config.text}</span>
    </div>
  );
}

// Sound-Effekt für Benachrichtigungen (optional)
export function useNotificationSound() {
  const audioRef = React.useRef(null);

  useEffect(() => {
    // Erstelle Audio-Element für Notification Sound
    audioRef.current = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdH2JkYuDd3F0fYSLkYuDd3F0fYSLkYuDd3F0fYSLkYuDd3F0fYSL');
    audioRef.current.volume = 0.3;
  }, []);

  const playSound = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(() => {});
    }
  }, []);

  return playSound;
}

export default ToastContainer;
