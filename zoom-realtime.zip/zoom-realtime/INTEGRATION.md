# 🔌 Integration in dein bestehendes Zoom 2026 Projekt

## Schnelle Integration (5 Minuten)

### 1. Server-Dateien kopieren

Kopiere diese Ordner in dein `server/` Verzeichnis:

```
server/
├── webhooks/
│   ├── zoomWebhookHandler.js
│   └── webhookRoutes.js
└── websocket/
    └── realtimeServer.js
```

### 2. Dependencies installieren

```bash
cd server
npm install ws uuid
```

### 3. In deiner server/index.js integrieren

```javascript
// Am Anfang der Datei
const http = require('http');
const { ZoomWebhookHandler } = require('./webhooks/zoomWebhookHandler');
const { createWebhookRoutes } = require('./webhooks/webhookRoutes');
const { RealtimeServer } = require('./websocket/realtimeServer');

// Express App erstellen
const app = express();
const server = http.createServer(app); // ← Wichtig: http.createServer verwenden!

// ... deine bestehenden Middleware & Routes ...

// Webhook Handler initialisieren
const webhookHandler = new ZoomWebhookHandler(process.env.ZOOM_WEBHOOK_SECRET_TOKEN);

// WebSocket Server initialisieren  
const realtimeServer = new RealtimeServer(server, { path: '/ws' });

// Webhook Routes registrieren
const webhookRoutes = createWebhookRoutes(webhookHandler, realtimeServer);
app.use('/webhook', webhookRoutes);

// Am Ende: server.listen statt app.listen
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
```

### 4. Frontend-Dateien kopieren

Kopiere in dein `client/src/` Verzeichnis:

```
client/src/
├── hooks/
│   └── useZoomRealtime.js
└── components/
    ├── ToastNotifications.jsx
    └── LiveEventsPanel.jsx
```

### 5. In deiner React App verwenden

```jsx
// client/src/App.jsx oder Layout-Komponente
import { ToastContainer } from './components/ToastNotifications';
import { LiveEventsPanel } from './components/LiveEventsPanel';

function App() {
  return (
    <>
      {/* Toast Notifications - einmal global */}
      <ToastContainer position="top-right" />
      
      {/* Rest deiner App */}
      <YourExistingLayout>
        {/* Live Events Panel irgendwo einbinden */}
        <LiveEventsPanel />
      </YourExistingLayout>
    </>
  );
}
```

### 6. Environment Variable

In deiner `.env`:

```env
ZOOM_WEBHOOK_SECRET_TOKEN=dein_webhook_secret
```

---

## 🎯 Minimalste Integration

Wenn du nur den Hook willst:

```jsx
import { useZoomRealtime } from './hooks/useZoomRealtime';

function Dashboard() {
  const { events, isConnected } = useZoomRealtime();

  return (
    <div>
      <span className={isConnected ? 'text-green-500' : 'text-red-500'}>
        {isConnected ? '🟢 Live' : '🔴 Offline'}
      </span>
      
      <ul>
        {events.slice(0, 5).map(e => (
          <li key={e.id}>{e.ui?.icon} {e.ui?.title}</li>
        ))}
      </ul>
    </div>
  );
}
```

---

## 🧪 Testen

1. Server starten
2. Test-Event senden:
   ```bash
   curl -X POST http://localhost:3001/webhook/test -H "Content-Type: application/json"
   ```
3. Im Browser sollte Toast erscheinen ✅

---

## Zoom Marketplace Setup

1. marketplace.zoom.us → Deine App
2. Feature → Event Subscriptions → Enable
3. Event notification endpoint URL: `https://deine-domain/webhook/zoom`
4. Events auswählen (meeting.started, meeting.ended, etc.)
5. Secret Token kopieren → `.env`
