#!/bin/bash
# Zoom Realtime - Quick Test Script

echo "🧪 Zoom Realtime Test Script"
echo "=============================="
echo ""

BASE_URL="${1:-http://localhost:3001}"

echo "📍 Testing: $BASE_URL"
echo ""

# Health Check
echo "1️⃣  Health Check..."
curl -s "$BASE_URL/health" | jq . 2>/dev/null || curl -s "$BASE_URL/health"
echo ""

# API Info
echo "2️⃣  API Info..."
curl -s "$BASE_URL/api" | jq . 2>/dev/null || curl -s "$BASE_URL/api"
echo ""

# Sende Test Events
echo "3️⃣  Sende Test Events..."

echo "   → Meeting gestartet"
curl -s -X POST "$BASE_URL/webhook/test" \
  -H "Content-Type: application/json" \
  -d '{"eventType": "meeting.started"}' | jq -r '.status' 2>/dev/null || echo "sent"

sleep 1

echo "   → Teilnehmer beigetreten"
curl -s -X POST "$BASE_URL/webhook/test" \
  -H "Content-Type: application/json" \
  -d '{"eventType": "meeting.participant_joined"}' | jq -r '.status' 2>/dev/null || echo "sent"

sleep 1

echo "   → Recording fertig"
curl -s -X POST "$BASE_URL/webhook/test" \
  -H "Content-Type: application/json" \
  -d '{"eventType": "recording.completed"}' | jq -r '.status' 2>/dev/null || echo "sent"

echo ""

# Event History
echo "4️⃣  Event History..."
curl -s "$BASE_URL/webhook/events?limit=5" | jq '.events[].type' 2>/dev/null || curl -s "$BASE_URL/webhook/events?limit=5"
echo ""

# WebSocket Stats
echo "5️⃣  WebSocket Stats..."
curl -s "$BASE_URL/webhook/stats" | jq . 2>/dev/null || curl -s "$BASE_URL/webhook/stats"
echo ""

echo "✅ Tests abgeschlossen!"
echo ""
echo "📌 Nächste Schritte:"
echo "   1. Öffne http://localhost:5173 im Browser"
echo "   2. Starte ngrok: npx ngrok http 3001"
echo "   3. Trage ngrok URL in Zoom Marketplace ein"
