# 🚀 Zoom Control Center - Echtzeit Events

Empfange Zoom Webhook-Events in Echtzeit und zeige sie live im Browser an.

## ✨ Features

- **WebSocket Server** - Echtzeit-Updates an alle verbundenen Clients
- **Zoom Webhooks** - Verarbeitung aller Zoom Event-Typen
- **React Hook** - `useZoomRealtime()` für einfache Integration
- **Toast Notifications** - Pop-up Benachrichtigungen bei Events
- **Live Events Panel** - Scrollbare Event-Liste mit Filterung
- **Event History** - Letzte 100 Events werden gespeichert

## 📦 Unterstützte Events

| Kategorie | Events |
|-----------|--------|
| **Meetings** | `meeting.started`, `meeting.ended`, `participant_joined`, `participant_left` |
| **Recordings** | `recording.started`, `recording.completed`, `recording.deleted` |
| **Webinars** | `webinar.started`, `webinar.ended`, `registration_created` |
| **Users** | `user.created`, `user.deactivated`, `user.updated` |
| **Phone** | `phone.callee_answered`, `phone.callee_ended` |

## 🛠️ Installation

### 1. Server starten

```bash
cd server
npm install
cp .env.example .env  # Dann Credentials eintragen!
npm run dev
```

### 2. Öffentlichen Tunnel erstellen (für Zoom Webhooks)

```bash
# Mit ngrok
npx ngrok http 3001

# Oder mit localtunnel
npx localtunnel --port 3001
```

Die URL (z.B. `https://abc123.ngrok.io`) brauchst du für Zoom.

### 3. Zoom Marketplace konfigurieren

1. Gehe zu [marketplace.zoom.us](https://marketplace.zoom.us)
2. Öffne deine App → **Feature** → **Event Subscriptions**
3. Aktiviere Event Subscriptions
4. **Event notification endpoint URL**: `https://deine-ngrok-url/webhook/zoom`
5. Wähle die Events aus die du empfangen willst
6. Kopiere das **Secret Token** in deine `.env`

### 4. React-Komponenten integrieren

```jsx
// In deiner App.jsx
import { ToastContainer, ConnectionBadge } from './components/ToastNotifications';
import { LiveEventsPanel } from './components/LiveEventsPanel';

function App() {
  return (
    <div>
      {/* Toast Notifications (global) */}
      <ToastContainer position="top-right" />
      
      {/* Connection Status */}
      <ConnectionBadge />
      
      {/* Live Events Panel */}
      <LiveEventsPanel />
    </div>
  );
}
```

### 5. Hook direkt verwenden

```jsx
import { useZoomRealtime } from './hooks/useZoomRealtime';

function MyComponent() {
  const { 
    events,           // Array der empfangenen Events
    isConnected,      // WebSocket verbunden?
    connectionStatus, // 'connected' | 'connecting' | 'disconnected' | 'error'
    clearEvents,      // Events leeren
    subscribe,        // Zu Event-Typen subscriben
    unsubscribe       // Events abbestellen
  } = useZoomRealtime({
    onEvent: (event) => {
      console.log('Neues Event:', event);
    }
  });

  return (
    <div>
      <p>Status: {connectionStatus}</p>
      <p>Events: {events.length}</p>
    </div>
  );
}
```

## 🧪 Testen ohne Zoom

Sende Test-Events über die API:

```bash
# Meeting gestartet
curl -X POST http://localhost:3001/webhook/test \
  -H "Content-Type: application/json" \
  -d '{"eventType": "meeting.started"}'

# Teilnehmer beigetreten
curl -X POST http://localhost:3001/webhook/test \
  -H "Content-Type: application/json" \
  -d '{"eventType": "meeting.participant_joined"}'

# Recording fertig
curl -X POST http://localhost:3001/webhook/test \
  -H "Content-Type: application/json" \
  -d '{"eventType": "recording.completed"}'
```

## 📡 API Endpoints

| Endpoint | Methode | Beschreibung |
|----------|---------|--------------|
| `/webhook/zoom` | POST | Zoom Webhook Endpoint |
| `/webhook/events` | GET | Event-Historie abrufen |
| `/webhook/test` | POST | Test-Event senden |
| `/webhook/stats` | GET | WebSocket Statistiken |
| `/webhook/clients` | GET | Verbundene Clients |
| `/health` | GET | Health Check |

## 🔌 WebSocket Protokoll

### Verbindung

```javascript
const ws = new WebSocket('ws://localhost:3001/ws');
```

### Client → Server Messages

```javascript
// Zu Event-Typen subscriben
{ "type": "subscribe", "events": ["meeting.started", "meeting.ended"] }

// Events abbestellen
{ "type": "unsubscribe", "events": ["meeting.ended"] }

// Meeting-Room beitreten (für Meeting-spezifische Updates)
{ "type": "join_room", "room": "meeting:123456789" }

// Ping
{ "type": "ping" }

// Stats anfragen
{ "type": "get_stats" }
```

### Server → Client Messages

```javascript
// Verbindung hergestellt
{ "type": "connection", "status": "connected", "clientId": "abc-123" }

// Event empfangen
{ 
  "type": "event", 
  "data": {
    "type": "meeting.started",
    "payload": { ... },
    "ui": {
      "icon": "🟢",
      "title": "Meeting gestartet",
      "message": "Team Standup wurde von host@example.com gestartet",
      "color": "green"
    }
  }
}

// Stats
{ "type": "stats", "connectedClients": 5, "rooms": [...] }
```

## 🎨 Anpassung

### Eigene Event-Formatierung

In `zoomWebhookHandler.js` unter `formatEventForUI()`:

```javascript
'custom.event': () => ({
  title: 'Mein Custom Event',
  message: `Nachricht: ${payload.data}`,
  icon: '🎉',
  color: 'purple'
})
```

### Toast Position ändern

```jsx
<ToastContainer position="bottom-right" maxToasts={3} />
```

Optionen: `top-right`, `top-left`, `bottom-right`, `bottom-left`, `top-center`, `bottom-center`

## 🔒 Sicherheit

- Webhook-Signatur wird automatisch verifiziert
- WebSocket unterstützt Authentication (erweiterbar)
- CORS ist auf `CLIENT_URL` beschränkt

## 📁 Projektstruktur

```
zoom-realtime/
├── server/
│   ├── index.js              # Express + WebSocket Server
│   ├── webhooks/
│   │   ├── zoomWebhookHandler.js  # Event-Verarbeitung
│   │   └── webhookRoutes.js       # API Routes
│   ├── websocket/
│   │   └── realtimeServer.js      # WebSocket Logic
│   ├── package.json
│   └── .env.example
│
└── client/
    └── src/
        ├── hooks/
        │   └── useZoomRealtime.js   # React Hook
        └── components/
            ├── ToastNotifications.jsx
            └── LiveEventsPanel.jsx
```

## 🐛 Troubleshooting

### WebSocket verbindet nicht
- Prüfe ob Server läuft: `http://localhost:3001/health`
- Prüfe CORS in `.env`
- Browser DevTools → Network → WS Tab

### Keine Events von Zoom
- ngrok URL noch gültig?
- Event Subscriptions aktiviert?
- Secret Token korrekt?
- Event-Typen ausgewählt?

### Test-Event curl funktioniert
```bash
curl http://localhost:3001/webhook/test -X POST -H "Content-Type: application/json" -d '{}'
```

---

Made with ❤️ für dein Zoom Control Center
