/**
 * Zoom Control Center - Server mit Echtzeit-Updates
 * Express + WebSocket Server
 */

require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const { ZoomWebhookHandler } = require('./webhooks/zoomWebhookHandler');
const { createWebhookRoutes } = require('./webhooks/webhookRoutes');
const { RealtimeServer } = require('./websocket/realtimeServer');

const app = express();
const server = http.createServer(app);

// Middleware
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:5173',
  credentials: true
}));
app.use(express.json());

// Request Logging
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} | ${req.method} ${req.path}`);
  next();
});

// =====================================================
// ZOOM WEBHOOK HANDLER INITIALISIEREN
// =====================================================
const webhookHandler = new ZoomWebhookHandler(
  process.env.ZOOM_WEBHOOK_SECRET_TOKEN || 'your-webhook-secret'
);

// Event-Handler registrieren (optional für serverseitige Logik)
webhookHandler.on('meeting.started', async (event) => {
  console.log(`🟢 Meeting gestartet: ${event.payload.object?.topic}`);
  // Hier könnte man z.B. in DB speichern, Slack notifizieren, etc.
});

webhookHandler.on('meeting.ended', async (event) => {
  console.log(`🔴 Meeting beendet: ${event.payload.object?.topic}`);
});

webhookHandler.on('recording.completed', async (event) => {
  console.log(`🎬 Aufnahme fertig: ${event.payload.object?.topic}`);
  // Automatischer Download könnte hier getriggert werden
});

// Catch-all für alle Events
webhookHandler.on('*', async (event) => {
  // Alle Events loggen
  console.log(`📌 Event: ${event.type}`);
});

// =====================================================
// WEBSOCKET SERVER INITIALISIEREN
// =====================================================
const realtimeServer = new RealtimeServer(server, {
  path: '/ws',
  heartbeatInterval: 30000
});

// =====================================================
// ROUTES
// =====================================================

// Health Check
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy',
    timestamp: new Date().toISOString(),
    websocket: {
      clients: realtimeServer.getStats().connectedClients
    }
  });
});

// Webhook Routes
const webhookRoutes = createWebhookRoutes(webhookHandler, realtimeServer);
app.use('/webhook', webhookRoutes);

// API Info
app.get('/api', (req, res) => {
  res.json({
    name: 'Zoom Control Center API',
    version: '1.0.0',
    endpoints: {
      webhook: {
        'POST /webhook/zoom': 'Zoom Webhook Endpoint (für Zoom Marketplace)',
        'GET /webhook/events': 'Event-Historie abrufen',
        'GET /webhook/stats': 'WebSocket Statistiken',
        'GET /webhook/clients': 'Verbundene Clients',
        'POST /webhook/test': 'Test-Event senden'
      },
      websocket: {
        'ws://localhost:3001/ws': 'WebSocket für Echtzeit-Events'
      }
    },
    eventTypes: [
      'meeting.started', 'meeting.ended',
      'meeting.participant_joined', 'meeting.participant_left',
      'recording.started', 'recording.completed',
      'webinar.started', 'webinar.ended',
      'user.created', 'user.deactivated'
    ]
  });
});

// =====================================================
// SERVER STARTEN
// =====================================================
const PORT = process.env.PORT || 3001;

server.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════════╗
║                                                            ║
║   🚀 Zoom Control Center Server                            ║
║                                                            ║
║   HTTP Server:  http://localhost:${PORT}                     ║
║   WebSocket:    ws://localhost:${PORT}/ws                    ║
║   Webhook URL:  http://localhost:${PORT}/webhook/zoom        ║
║                                                            ║
║   Für Zoom Marketplace:                                    ║
║   • Event Subscription URL: [ngrok-url]/webhook/zoom       ║
║   • Secret Token: In .env konfigurieren                    ║
║                                                            ║
╚════════════════════════════════════════════════════════════╝
  `);
});

// Graceful Shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down...');
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

module.exports = { app, server, webhookHandler, realtimeServer };
