/**
 * Zoom Webhook Routes
 * Express Router für eingehende Zoom Webhooks
 */

const express = require('express');
const router = express.Router();

/**
 * Factory-Funktion die Router mit WebhookHandler und RealtimeServer erstellt
 */
function createWebhookRoutes(webhookHandler, realtimeServer) {
  
  /**
   * POST /webhook/zoom
   * Haupt-Endpoint für Zoom Webhooks
   */
  router.post('/zoom', async (req, res) => {
    try {
      const { event, payload } = req.body;
      
      // URL Validation Challenge (bei Webhook-Erstellung in Zoom)
      if (event === 'endpoint.url_validation') {
        const { plainToken } = payload;
        const response = webhookHandler.generateChallengeResponse(plainToken);
        console.log('✅ Zoom URL Validation Challenge beantwortet');
        return res.status(200).json(response);
      }

      // Signatur verifizieren (optional aber empfohlen)
      if (process.env.ZOOM_WEBHOOK_SECRET_TOKEN && 
          req.headers['x-zm-signature']) {
        const isValid = webhookHandler.verifyWebhookSignature(req);
        if (!isValid) {
          console.warn('⚠️ Ungültige Webhook-Signatur');
          return res.status(401).json({ error: 'Invalid signature' });
        }
      }

      console.log(`📩 Webhook Event empfangen: ${event}`);

      // Event verarbeiten
      const processedEvent = await webhookHandler.processEvent(req.body);
      
      // Für UI formatieren
      const { ZoomWebhookHandler } = require('./zoomWebhookHandler');
      const formattedEvent = ZoomWebhookHandler.formatEventForUI(processedEvent);
      
      // An alle WebSocket-Clients broadcasten
      if (realtimeServer) {
        realtimeServer.broadcast(formattedEvent);
        
        // Meeting-spezifische Room-Updates
        const meetingId = payload?.object?.id;
        if (meetingId) {
          realtimeServer.broadcastToRoom(`meeting:${meetingId}`, {
            type: 'meeting_event',
            data: formattedEvent
          });
        }
      }

      // Zoom erwartet immer 200 OK
      res.status(200).json({ 
        status: 'success',
        eventId: processedEvent.id 
      });

    } catch (error) {
      console.error('❌ Webhook Verarbeitungsfehler:', error);
      // Trotzdem 200 senden, sonst versucht Zoom es erneut
      res.status(200).json({ status: 'error', message: error.message });
    }
  });

  /**
   * GET /webhook/events
   * Event-Historie abrufen
   */
  router.get('/events', (req, res) => {
    const { limit = 50, type } = req.query;
    const events = webhookHandler.getEventHistory(parseInt(limit), type);
    
    // Events für UI formatieren
    const { ZoomWebhookHandler } = require('./zoomWebhookHandler');
    const formattedEvents = events.map(e => ZoomWebhookHandler.formatEventForUI(e));
    
    res.json({
      count: formattedEvents.length,
      events: formattedEvents
    });
  });

  /**
   * GET /webhook/stats
   * WebSocket Stats
   */
  router.get('/stats', (req, res) => {
    const stats = realtimeServer ? realtimeServer.getStats() : { error: 'No realtime server' };
    res.json(stats);
  });

  /**
   * GET /webhook/clients
   * Verbundene WebSocket Clients
   */
  router.get('/clients', (req, res) => {
    const clients = realtimeServer ? realtimeServer.getConnectedClients() : [];
    res.json({ 
      count: clients.length,
      clients 
    });
  });

  /**
   * POST /webhook/test
   * Test-Event senden (für Entwicklung)
   */
  router.post('/test', async (req, res) => {
    const { eventType = 'meeting.started', customPayload } = req.body;
    
    // Simuliertes Event erstellen
    const testEvent = {
      event: eventType,
      event_ts: Date.now(),
      payload: customPayload || {
        account_id: 'TEST_ACCOUNT',
        object: {
          id: Math.floor(Math.random() * 1000000000),
          topic: 'Test Meeting ' + new Date().toLocaleTimeString(),
          host: {
            email: 'test@example.com',
            id: 'test-host-id'
          },
          start_time: new Date().toISOString(),
          duration: 60,
          participant: {
            user_name: 'Test User',
            email: 'testuser@example.com'
          }
        }
      }
    };

    const processedEvent = await webhookHandler.processEvent(testEvent);
    const { ZoomWebhookHandler } = require('./zoomWebhookHandler');
    const formattedEvent = ZoomWebhookHandler.formatEventForUI(processedEvent);
    
    if (realtimeServer) {
      realtimeServer.broadcast(formattedEvent);
    }

    res.json({ 
      status: 'Test event sent',
      event: formattedEvent 
    });
  });

  return router;
}

module.exports = { createWebhookRoutes };
